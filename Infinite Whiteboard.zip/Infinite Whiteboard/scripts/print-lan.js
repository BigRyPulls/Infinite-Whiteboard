// Prints the LAN-accessible URL(s) for this machine before the dev/preview
// server starts, so other devices on the same network know where to connect.
import { networkInterfaces } from 'os';

const mode = process.argv[2] || 'dev';
const port = mode === 'serve' ? 4000 : 5173;

function getLanAddresses() {
  const nets = networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] ?? []) {
      if (net.family === 'IPv4' && !net.internal) {
        addresses.push(net.address);
      }
    }
  }
  return addresses;
}

const addresses = getLanAddresses();

const GREEN = '\x1b[32m';
const CYAN = '\x1b[36m';
const DIM = '\x1b[2m';
const RESET = '\x1b[0m';
const BOLD = '\x1b[1m';

console.log('');
console.log(`${GREEN}${BOLD}  Infinite Whiteboard${RESET}${DIM} — local ${mode} server${RESET}`);
console.log(`${DIM}  ────────────────────────────────────────────${RESET}`);
console.log(`  ${CYAN}Local:${RESET}    http://localhost:${port}`);

if (addresses.length === 0) {
  console.log(`  ${DIM}No LAN network interface detected.${RESET}`);
} else {
  for (const addr of addresses) {
    console.log(`  ${CYAN}Network:${RESET}  http://${addr}:${port}`);
  }
  console.log('');
  console.log(`  ${DIM}Any device on the same Wi-Fi/LAN can open the Network URL above.${RESET}`);
}
console.log('');
