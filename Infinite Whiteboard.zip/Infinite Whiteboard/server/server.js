// Minimal production static file server for the built whiteboard app.
// Binds to 0.0.0.0 so any device on the local network can connect.
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const distDir = path.join(__dirname, '..', 'dist');

const app = express();
const PORT = process.env.PORT ? Number(process.env.PORT) : 4000;
const HOST = '0.0.0.0';

app.use(
  express.static(distDir, {
    maxAge: '1h',
    extensions: ['html'],
  })
);

// SPA fallback: any unmatched route serves index.html.
app.get('*', (_req, res) => {
  res.sendFile(path.join(distDir, 'index.html'));
});

app.listen(PORT, HOST, () => {
  console.log(`\x1b[32m  Serving production build from /dist on ${HOST}:${PORT}\x1b[0m`);
});
