import type { BoardElement } from './Element';
import type { Waypoint } from './Waypoint';
import type { CameraState } from './CameraState';

export const BOARD_FORMAT_VERSION = 1;

export interface BoardMetadata {
  name: string;
  createdAt: number;
  updatedAt: number;
}

/** The full serializable state of a whiteboard — this is exactly what gets
 * written to a `.json` board file and to the localStorage autosave slot. */
export interface BoardFile {
  formatVersion: number;
  metadata: BoardMetadata;
  camera: CameraState;
  elements: BoardElement[];
  waypoints: Waypoint[];
}

export function createEmptyBoard(name = 'Untitled Board'): BoardFile {
  const now = Date.now();
  return {
    formatVersion: BOARD_FORMAT_VERSION,
    metadata: { name, createdAt: now, updatedAt: now },
    camera: { x: 0, y: 0, zoom: 1 },
    elements: [],
    waypoints: [],
  };
}
