/** Camera describes the viewport into the infinite world. Objects never
 * move to accommodate navigation — only the camera does. */
export interface CameraState {
  x: number;
  y: number;
  zoom: number;
}

export const MIN_ZOOM = 0.01; // 1%
export const MAX_ZOOM = 10; // 1000%

export function clampZoom(zoom: number): number {
  if (zoom < MIN_ZOOM) return MIN_ZOOM;
  if (zoom > MAX_ZOOM) return MAX_ZOOM;
  return zoom;
}

export function createDefaultCamera(): CameraState {
  return { x: 0, y: 0, zoom: 1 };
}
