export interface Waypoint {
  id: string;
  name: string;
  x: number;
  y: number;
  zoom: number;
  createdAt: number;
  color?: string;
}

let wpCounter = 0;
export function generateWaypointId(): string {
  wpCounter += 1;
  return `wp_${Date.now().toString(36)}_${wpCounter.toString(36)}`;
}

export const WAYPOINT_COLORS = ['#39ff9d', '#5ad8ff', '#a78bfa', '#ffb454', '#ff5d7a'] as const;
