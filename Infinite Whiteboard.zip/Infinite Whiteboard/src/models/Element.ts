/**
 * Element model — every object placed on the board shares a common
 * transform/metadata envelope (`ElementBase`) and adds type-specific
 * payload fields. Discriminated on `type` for exhaustive switches in the
 * renderer, hit-testing, and serialization code.
 */

export type ElementType = 'stroke' | 'text' | 'image' | 'shape';

export interface ElementBase {
  id: string;
  type: ElementType;
  /** World-space bounding box (pre-rotation), top-left anchored. */
  x: number;
  y: number;
  width: number;
  height: number;
  /** Radians, applied around the element's center. */
  rotation: number;
  scaleX: number;
  scaleY: number;
  opacity: number;
  /** Higher layer draws on top. Dense integers, reassigned on reorder. */
  layer: number;
  visible: boolean;
  locked: boolean;
  createdAt: number;
  updatedAt: number;
  metadata: Record<string, unknown>;
}

export interface StrokePoint {
  x: number;
  y: number;
  /** When true, the renderer starts a new subpath here instead of curving
   * from the previous point — used to represent gaps left by the eraser
   * without needing to split a stroke into separate elements. */
  newSubpath?: boolean;
}

export interface StrokeElement extends ElementBase {
  type: 'stroke';
  /** Points in world space, already offset by (x, y) — i.e. absolute. */
  points: StrokePoint[];
  color: string;
  size: number;
  smoothing: number;
}

export type TextAlign = 'left' | 'center' | 'right';

export interface TextElement extends ElementBase {
  type: 'text';
  text: string;
  fontSize: number;
  fontFamily: string;
  bold: boolean;
  italic: boolean;
  align: TextAlign;
  color: string;
  lineHeight: number;
}

export interface ImageElement extends ElementBase {
  type: 'image';
  /** Cache key used by ImageLoader; also the persisted data URL. */
  src: string;
  naturalWidth: number;
  naturalHeight: number;
  aspectLocked: boolean;
}

export type ShapeKind = 'rectangle' | 'ellipse' | 'line' | 'arrow';

export interface ShapeElement extends ElementBase {
  type: 'shape';
  shape: ShapeKind;
  fillColor: string | null;
  strokeColor: string;
  strokeWidth: number;
}

export type BoardElement = StrokeElement | TextElement | ImageElement | ShapeElement;

let idCounter = 0;
export function generateId(prefix = 'el'): string {
  idCounter += 1;
  return `${prefix}_${Date.now().toString(36)}_${idCounter.toString(36)}`;
}

export function createElementBase(
  partial: Partial<ElementBase> & Pick<ElementBase, 'type' | 'x' | 'y' | 'width' | 'height'>
): ElementBase {
  const now = Date.now();
  return {
    id: partial.id ?? generateId(partial.type),
    type: partial.type,
    x: partial.x,
    y: partial.y,
    width: partial.width,
    height: partial.height,
    rotation: partial.rotation ?? 0,
    scaleX: partial.scaleX ?? 1,
    scaleY: partial.scaleY ?? 1,
    opacity: partial.opacity ?? 1,
    layer: partial.layer ?? 0,
    visible: partial.visible ?? true,
    locked: partial.locked ?? false,
    createdAt: partial.createdAt ?? now,
    updatedAt: partial.updatedAt ?? now,
    metadata: partial.metadata ?? {},
  };
}

/** Axis-aligned bounding box, accounting for rotation, in world space. */
export function getElementBounds(el: ElementBase): { minX: number; minY: number; maxX: number; maxY: number } {
  const w = el.width * el.scaleX;
  const h = el.height * el.scaleY;
  if (el.rotation === 0) {
    const x0 = Math.min(el.x, el.x + w);
    const x1 = Math.max(el.x, el.x + w);
    const y0 = Math.min(el.y, el.y + h);
    const y1 = Math.max(el.y, el.y + h);
    return { minX: x0, minY: y0, maxX: x1, maxY: y1 };
  }
  const absW = Math.abs(w);
  const absH = Math.abs(h);
  const cx = el.x + w / 2;
  const cy = el.y + h / 2;
  const cos = Math.abs(Math.cos(el.rotation));
  const sin = Math.abs(Math.sin(el.rotation));
  const rw = absW * cos + absH * sin;
  const rh = absW * sin + absH * cos;
  return {
    minX: cx - rw / 2,
    minY: cy - rh / 2,
    maxX: cx + rw / 2,
    maxY: cy + rh / 2,
  };
}
