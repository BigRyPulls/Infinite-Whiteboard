export type ResizeListener = (width: number, height: number) => void;

/**
 * Owns the canvas element, its device-pixel-ratio scaling, and resize
 * handling. Keeps the backing store crisp on HiDPI screens without
 * leaking that complexity into the renderer.
 */
export class CanvasManager {
  readonly canvas: HTMLCanvasElement;
  readonly ctx: CanvasRenderingContext2D;
  private dpr = 1;
  private cssWidth = 0;
  private cssHeight = 0;
  private resizeListeners = new Set<ResizeListener>();
  private resizeObserver: ResizeObserver;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
    if (!ctx) throw new Error('Canvas 2D context unavailable');
    this.ctx = ctx;

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(canvas.parentElement ?? canvas);
    this.handleResize();
  }

  onResize(fn: ResizeListener): () => void {
    this.resizeListeners.add(fn);
    return () => this.resizeListeners.delete(fn);
  }

  get width(): number {
    return this.cssWidth;
  }
  get height(): number {
    return this.cssHeight;
  }

  private handleResize(): void {
    const parent = this.canvas.parentElement ?? this.canvas;
    const rect = parent.getBoundingClientRect();
    const width = Math.max(1, Math.round(rect.width));
    const height = Math.max(1, Math.round(rect.height));
    const dpr = Math.min(window.devicePixelRatio || 1, 3);

    if (width === this.cssWidth && height === this.cssHeight && dpr === this.dpr) return;

    this.cssWidth = width;
    this.cssHeight = height;
    this.dpr = dpr;

    this.canvas.width = Math.round(width * dpr);
    this.canvas.height = Math.round(height * dpr);
    this.canvas.style.width = `${width}px`;
    this.canvas.style.height = `${height}px`;

    for (const fn of this.resizeListeners) fn(width, height);
  }

  /** Resets the transform to device pixels and applies DPR scaling so
   * all subsequent drawing can happen in CSS-pixel space. */
  applyDprTransform(): void {
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
  }

  dispose(): void {
    this.resizeObserver.disconnect();
  }
}
