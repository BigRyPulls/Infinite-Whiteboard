export type ImageReadyListener = (src: string) => void;

interface CacheEntry {
  image: HTMLImageElement | ImageBitmap;
  width: number;
  height: number;
}

/**
 * Decodes and caches bitmap data for image elements so the renderer never
 * re-decodes the same source twice. Uses `createImageBitmap` when
 * available for off-main-thread decoding, falling back to `HTMLImageElement`.
 */
export class ImageLoader {
  private cache = new Map<string, CacheEntry>();
  private pending = new Map<string, Promise<CacheEntry>>();
  private listeners = new Set<ImageReadyListener>();

  onReady(fn: ImageReadyListener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  get(src: string): CacheEntry | undefined {
    return this.cache.get(src);
  }

  isLoaded(src: string): boolean {
    return this.cache.has(src);
  }

  /** Rough decoded-pixel memory footprint of everything currently cached. */
  estimateBytes(): number {
    let total = 0;
    for (const entry of this.cache.values()) total += entry.width * entry.height * 4;
    return total;
  }

  load(src: string): Promise<CacheEntry> {
    const cached = this.cache.get(src);
    if (cached) return Promise.resolve(cached);

    const inflight = this.pending.get(src);
    if (inflight) return inflight;

    const promise = this.decode(src)
      .then((entry) => {
        this.cache.set(src, entry);
        this.pending.delete(src);
        for (const fn of this.listeners) fn(src);
        return entry;
      })
      .catch((err) => {
        this.pending.delete(src);
        throw err;
      });

    this.pending.set(src, promise);
    return promise;
  }

  private async decode(src: string): Promise<CacheEntry> {
    if (typeof createImageBitmap === 'function') {
      try {
        const blob = await (await fetch(src)).blob();
        const bitmap = await createImageBitmap(blob);
        return { image: bitmap, width: bitmap.width, height: bitmap.height };
      } catch {
        // Fall through to <img> path (e.g. SVG edge cases, fetch failures on data URLs).
      }
    }
    return new Promise<CacheEntry>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve({ image: img, width: img.naturalWidth, height: img.naturalHeight });
      img.onerror = () => reject(new Error('Failed to decode image'));
      img.src = src;
    });
  }

  dispose(): void {
    for (const entry of this.cache.values()) {
      if (entry.image instanceof ImageBitmap) entry.image.close();
    }
    this.cache.clear();
    this.pending.clear();
  }
}

/** Reads a File as a data URL — used for local import + JSON embedding. */
export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

/** Generates a small thumbnail data URL from a loaded image, capped to
 * `maxSize` on the longest edge. Used for recent-file previews etc. */
export function createThumbnail(image: HTMLImageElement | ImageBitmap, maxSize = 96): string {
  const w = image.width;
  const h = image.height;
  const scale = Math.min(1, maxSize / Math.max(w, h));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(w * scale));
  canvas.height = Math.max(1, Math.round(h * scale));
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';
  ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/png');
}
