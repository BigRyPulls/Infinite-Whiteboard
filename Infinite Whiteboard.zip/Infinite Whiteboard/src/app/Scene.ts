import type { BoardElement } from '@/models/Element';
import { getElementBounds } from '@/models/Element';
import { SpatialIndex, type AABB } from './SpatialIndex';

export type SceneListener = () => void;

/**
 * Retained scene graph: the authoritative store of every element on the
 * board. Backed by a spatial index for O(log n) viewport culling instead
 * of iterating every element every frame. Mutations mark the scene dirty
 * so the render loop can skip work when nothing changed.
 */
export class Scene {
  private elements = new Map<string, BoardElement>();
  private index = new SpatialIndex();
  private dirty = true;
  private listeners = new Set<SceneListener>();
  private nextLayer = 1;

  onChange(fn: SceneListener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private notify(): void {
    this.dirty = true;
    for (const fn of this.listeners) fn();
  }

  isDirty(): boolean {
    return this.dirty;
  }

  clearDirty(): void {
    this.dirty = false;
  }

  markDirty(): void {
    this.dirty = true;
  }

  get size(): number {
    return this.elements.size;
  }

  allocateLayer(): number {
    this.nextLayer += 1;
    return this.nextLayer;
  }

  addElement(el: BoardElement, notify = true): void {
    this.elements.set(el.id, el);
    this.index.insert(el.id, getElementBounds(el));
    if (el.layer >= this.nextLayer) this.nextLayer = el.layer + 1;
    if (notify) this.notify();
  }

  removeElement(id: string, notify = true): void {
    this.elements.delete(id);
    this.index.remove(id);
    if (notify) this.notify();
  }

  getElement(id: string): BoardElement | undefined {
    return this.elements.get(id);
  }

  has(id: string): boolean {
    return this.elements.has(id);
  }

  /** Replaces an element in place and refreshes its spatial bounds. */
  updateElement(id: string, mutator: (el: BoardElement) => void, notify = true): void {
    const el = this.elements.get(id);
    if (!el) return;
    mutator(el);
    el.updatedAt = Date.now();
    this.index.update(id, getElementBounds(el));
    if (notify) this.notify();
  }

  refreshBounds(id: string): void {
    const el = this.elements.get(id);
    if (!el) return;
    this.index.update(id, getElementBounds(el));
  }

  getAll(): BoardElement[] {
    return Array.from(this.elements.values());
  }

  getAllSortedByLayer(): BoardElement[] {
    return this.getAll().sort((a, b) => a.layer - b.layer);
  }

  /** Viewport-culled query, sorted by layer for correct paint order. */
  queryVisible(rect: AABB): BoardElement[] {
    const ids = this.index.query(rect);
    const result: BoardElement[] = [];
    for (const id of ids) {
      const el = this.elements.get(id);
      if (el && el.visible) result.push(el);
    }
    result.sort((a, b) => a.layer - b.layer);
    return result;
  }

  clear(notify = true): void {
    this.elements.clear();
    this.index.clear();
    this.nextLayer = 1;
    if (notify) this.notify();
  }

  loadElements(elements: BoardElement[]): void {
    this.clear(false);
    for (const el of elements) this.addElement(el, false);
    this.notify();
  }

  /** All layer-reorder helpers return the set of {id, before, after}
   * layer changes they made, so callers can build accurate, fully
   * undoable history commands (including any swapped neighbor). */
  bringToFront(id: string): { id: string; before: number; after: number }[] {
    const el = this.elements.get(id);
    if (!el) return [];
    const before = el.layer;
    el.layer = this.allocateLayer();
    this.notify();
    return [{ id, before, after: el.layer }];
  }

  sendToBack(id: string): { id: string; before: number; after: number }[] {
    const el = this.elements.get(id);
    if (!el) return [];
    const before = el.layer;
    const minLayer = Math.min(0, ...this.getAll().map((e) => e.layer));
    el.layer = minLayer - 1;
    this.notify();
    return [{ id, before, after: el.layer }];
  }

  bringForward(id: string): { id: string; before: number; after: number }[] {
    const sorted = this.getAllSortedByLayer();
    const idx = sorted.findIndex((e) => e.id === id);
    if (idx === -1 || idx === sorted.length - 1) return [];
    const next = sorted[idx + 1]!;
    const cur = sorted[idx]!;
    const changes = [
      { id: cur.id, before: cur.layer, after: next.layer },
      { id: next.id, before: next.layer, after: cur.layer },
    ];
    const tmp = cur.layer;
    cur.layer = next.layer;
    next.layer = tmp;
    this.notify();
    return changes;
  }

  sendBackward(id: string): { id: string; before: number; after: number }[] {
    const sorted = this.getAllSortedByLayer();
    const idx = sorted.findIndex((e) => e.id === id);
    if (idx <= 0) return [];
    const prev = sorted[idx - 1]!;
    const cur = sorted[idx]!;
    const changes = [
      { id: cur.id, before: cur.layer, after: prev.layer },
      { id: prev.id, before: prev.layer, after: cur.layer },
    ];
    const tmp = cur.layer;
    cur.layer = prev.layer;
    prev.layer = tmp;
    this.notify();
    return changes;
  }
}
