import type { Scene } from './Scene';
import type { BoardElement } from '@/models/Element';

export interface Command {
  label: string;
  execute(): void;
  undo(): void;
}

const MAX_HISTORY = 100;

export type HistoryListener = () => void;

/** Linear undo/redo command stack, capped at MAX_HISTORY entries. Commands
 * capture just enough state to invert themselves cheaply — no full-scene
 * snapshots — so history stays fast even with thousands of elements. */
export class History {
  private past: Command[] = [];
  private future: Command[] = [];
  private listeners = new Set<HistoryListener>();

  onChange(fn: HistoryListener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private notify(): void {
    for (const fn of this.listeners) fn();
  }

  get canUndo(): boolean {
    return this.past.length > 0;
  }
  get canRedo(): boolean {
    return this.future.length > 0;
  }

  /** Executes and records a command. */
  push(command: Command): void {
    command.execute();
    this.past.push(command);
    if (this.past.length > MAX_HISTORY) this.past.shift();
    this.future.length = 0;
    this.notify();
  }

  /** Records a command that has already been executed (e.g. a drag that
   * already mutated the scene live and just needs to be made undoable). */
  record(command: Command): void {
    this.past.push(command);
    if (this.past.length > MAX_HISTORY) this.past.shift();
    this.future.length = 0;
    this.notify();
  }

  undo(): void {
    const cmd = this.past.pop();
    if (!cmd) return;
    cmd.undo();
    this.future.push(cmd);
    this.notify();
  }

  redo(): void {
    const cmd = this.future.pop();
    if (!cmd) return;
    cmd.execute();
    this.past.push(cmd);
    this.notify();
  }

  clear(): void {
    this.past = [];
    this.future = [];
    this.notify();
  }
}

// ---- Concrete, reusable commands -----------------------------------------

export class AddElementCommand implements Command {
  label = 'Create';
  constructor(private scene: Scene, private element: BoardElement) {}
  execute(): void {
    this.scene.addElement(this.element);
  }
  undo(): void {
    this.scene.removeElement(this.element.id);
  }
}

export class RemoveElementsCommand implements Command {
  label = 'Delete';
  private snapshots: BoardElement[];
  constructor(private scene: Scene, elements: BoardElement[]) {
    this.snapshots = elements.map((e) => structuredClone(e));
  }
  execute(): void {
    for (const el of this.snapshots) this.scene.removeElement(el.id);
  }
  undo(): void {
    for (const el of this.snapshots) this.scene.addElement(structuredClone(el));
  }
}

export class AddElementsCommand implements Command {
  label = 'Create';
  constructor(private scene: Scene, private elements: BoardElement[]) {}
  execute(): void {
    for (const el of this.elements) this.scene.addElement(el);
  }
  undo(): void {
    for (const el of this.elements) this.scene.removeElement(el.id);
  }
}

/** Generic before/after patch command for property edits, moves, resizes,
 * rotations — anything expressible as "these fields changed on this
 * element". */
export class UpdateElementCommand implements Command {
  label = 'Update';
  constructor(
    private scene: Scene,
    private id: string,
    private before: Record<string, unknown>,
    private after: Record<string, unknown>
  ) {}
  execute(): void {
    this.scene.updateElement(this.id, (el) => Object.assign(el, this.after));
  }
  undo(): void {
    this.scene.updateElement(this.id, (el) => Object.assign(el, this.before));
  }
}

export class BatchCommand implements Command {
  label = 'Batch';
  constructor(private commands: Command[], label?: string) {
    if (label) this.label = label;
  }
  execute(): void {
    for (const c of this.commands) c.execute();
  }
  undo(): void {
    for (let i = this.commands.length - 1; i >= 0; i--) this.commands[i]!.undo();
  }
}
