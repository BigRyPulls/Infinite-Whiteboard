import { type CameraState, clampZoom, createDefaultCamera } from '@/models/CameraState';

export type CameraListener = () => void;

interface CameraAnimation {
  fromX: number;
  fromY: number;
  fromZoom: number;
  toX: number;
  toY: number;
  toZoom: number;
  start: number;
  duration: number;
  ease: (t: number) => number;
  onDone?: () => void;
}

function easeInOutCubic(t: number): number {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

/**
 * Owns the viewport transform (x, y, zoom) in world space. The camera is
 * the ONLY thing that changes during navigation — elements keep their
 * world coordinates forever. Provides world<->screen conversions and
 * smooth animated transitions (used by waypoint jumps, fit-to-selection).
 */
export class Camera {
  private state: CameraState = createDefaultCamera();
  private listeners = new Set<CameraListener>();
  private animation: CameraAnimation | null = null;
  private viewportWidth = 0;
  private viewportHeight = 0;

  get x(): number {
    return this.state.x;
  }
  get y(): number {
    return this.state.y;
  }
  get zoom(): number {
    return this.state.zoom;
  }
  get isAnimating(): boolean {
    return this.animation !== null;
  }

  setViewportSize(width: number, height: number): void {
    this.viewportWidth = width;
    this.viewportHeight = height;
  }

  getState(): CameraState {
    return { ...this.state };
  }

  setState(state: CameraState, notify = true): void {
    this.animation = null;
    this.state = { x: state.x, y: state.y, zoom: clampZoom(state.zoom) };
    if (notify) this.emit();
  }

  onChange(fn: CameraListener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit(): void {
    for (const fn of this.listeners) fn();
  }

  /** Pan by a screen-space delta (pixels), independent of zoom. */
  panByScreenDelta(dx: number, dy: number): void {
    this.animation = null;
    this.state.x -= dx / this.state.zoom;
    this.state.y -= dy / this.state.zoom;
    this.emit();
  }

  panByWorldDelta(dx: number, dy: number): void {
    this.animation = null;
    this.state.x += dx;
    this.state.y += dy;
    this.emit();
  }

  /** Zoom while keeping the given screen point visually stationary. */
  zoomAt(screenX: number, screenY: number, factor: number): void {
    this.animation = null;
    const worldBefore = this.screenToWorld(screenX, screenY);
    const newZoom = clampZoom(this.state.zoom * factor);
    if (newZoom === this.state.zoom) return;
    this.state.zoom = newZoom;
    const worldAfter = this.screenToWorld(screenX, screenY);
    this.state.x += worldBefore.x - worldAfter.x;
    this.state.y += worldBefore.y - worldAfter.y;
    this.emit();
  }

  setZoomAt(screenX: number, screenY: number, zoom: number): void {
    this.animation = null;
    const worldBefore = this.screenToWorld(screenX, screenY);
    this.state.zoom = clampZoom(zoom);
    const worldAfter = this.screenToWorld(screenX, screenY);
    this.state.x += worldBefore.x - worldAfter.x;
    this.state.y += worldBefore.y - worldAfter.y;
    this.emit();
  }

  screenToWorld(sx: number, sy: number): { x: number; y: number } {
    return {
      x: this.state.x + (sx - this.viewportWidth / 2) / this.state.zoom,
      y: this.state.y + (sy - this.viewportHeight / 2) / this.state.zoom,
    };
  }

  worldToScreen(wx: number, wy: number): { x: number; y: number } {
    return {
      x: (wx - this.state.x) * this.state.zoom + this.viewportWidth / 2,
      y: (wy - this.state.y) * this.state.zoom + this.viewportHeight / 2,
    };
  }

  /** Visible world-space rectangle for the current viewport. */
  getVisibleWorldRect(): { minX: number; minY: number; maxX: number; maxY: number } {
    const halfW = this.viewportWidth / 2 / this.state.zoom;
    const halfH = this.viewportHeight / 2 / this.state.zoom;
    return {
      minX: this.state.x - halfW,
      minY: this.state.y - halfH,
      maxX: this.state.x + halfW,
      maxY: this.state.y + halfH,
    };
  }

  animateTo(target: CameraState, duration = 300, onDone?: () => void): void {
    this.animation = {
      fromX: this.state.x,
      fromY: this.state.y,
      fromZoom: this.state.zoom,
      toX: target.x,
      toY: target.y,
      toZoom: clampZoom(target.zoom),
      start: performance.now(),
      duration,
      ease: easeInOutCubic,
      onDone,
    };
  }

  /** Advances any in-flight animation. Returns true if something changed
   * and a re-render is needed. */
  tick(now: number): boolean {
    if (!this.animation) return false;
    const a = this.animation;
    const t = Math.min(1, (now - a.start) / a.duration);
    const e = a.ease(t);
    this.state.x = a.fromX + (a.toX - a.fromX) * e;
    this.state.y = a.fromY + (a.toY - a.fromY) * e;
    this.state.zoom = a.fromZoom + (a.toZoom - a.fromZoom) * e;
    this.emit();
    if (t >= 1) {
      const onDone = a.onDone;
      this.animation = null;
      onDone?.();
    }
    return true;
  }
}
