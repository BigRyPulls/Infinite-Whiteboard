import type { Camera } from './Camera';
import type { CanvasManager } from './CanvasManager';
import type { Tool, PointerInfo } from '@/tools/Tool';

export interface InputCallbacks {
  getActiveTool: () => Tool;
  requestRender: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onSave: () => void;
  onOpen: () => void;
  onCopy: () => void;
  onPaste: () => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onEscape: () => void;
  onContextMenu: (clientX: number, clientY: number) => void;
  onSelectAll: () => void;
  isTextEditing: () => boolean;
  onToolShortcut: (key: string) => void;
}

interface TrackedPointer {
  x: number;
  y: number;
  pointerType: string;
}

const WHEEL_ZOOM_SENSITIVITY = 0.0016;

/**
 * Translates raw DOM pointer/wheel/keyboard events into camera
 * navigation (pan/zoom, always available) and tool-specific gestures
 * (delegated to whichever Tool is currently active). Multi-touch pointers
 * are tracked to support two-finger pan + pinch-zoom independent of the
 * active tool.
 */
export class Input {
  private pointers = new Map<number, TrackedPointer>();
  private spaceHeld = false;
  private middlePanning = false;
  private lastPanX = 0;
  private lastPanY = 0;
  private pinchStartDist = 0;
  private pinchStartZoom = 1;
  private toolGestureActive = false;
  private toolPointerId: number | null = null;

  constructor(private canvasManager: CanvasManager, private camera: Camera, private callbacks: InputCallbacks) {
    const canvas = canvasManager.canvas;
    canvas.addEventListener('pointerdown', this.onPointerDown);
    canvas.addEventListener('pointermove', this.onPointerMove);
    window.addEventListener('pointerup', this.onPointerUp);
    window.addEventListener('pointercancel', this.onPointerUp);
    canvas.addEventListener('wheel', this.onWheel, { passive: false });
    canvas.addEventListener('contextmenu', this.onContextMenu);
    canvas.addEventListener('dblclick', this.onDoubleClick);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.resetTransientState);
  }

  private toPointerInfo(e: PointerEvent): PointerInfo {
    const rect = this.canvasManager.canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const world = this.camera.screenToWorld(sx, sy);
    return {
      screenX: sx,
      screenY: sy,
      worldX: world.x,
      worldY: world.y,
      button: e.button,
      shiftKey: e.shiftKey,
      altKey: e.altKey,
      ctrlKey: e.ctrlKey || e.metaKey,
      pointerType: e.pointerType,
      pointerId: e.pointerId,
    };
  }

  private onPointerDown = (e: PointerEvent): void => {
    this.canvasManager.canvas.setPointerCapture(e.pointerId);
    this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY, pointerType: e.pointerType });

    if (this.pointers.size === 2) {
      if (this.toolGestureActive && this.toolPointerId !== null) {
        const info = this.toPointerInfo(e);
        this.callbacks.getActiveTool().onPointerUp(info);
        this.toolGestureActive = false;
        this.toolPointerId = null;
      }
      this.startPinch();
      return;
    }
    if (this.pointers.size > 2) return;

    const info = this.toPointerInfo(e);

    if (e.button === 1 || this.spaceHeld) {
      this.middlePanning = true;
      this.lastPanX = info.screenX;
      this.lastPanY = info.screenY;
      this.canvasManager.canvas.style.cursor = 'grabbing';
      return;
    }

    if (e.button === 2) return; // handled by contextmenu

    this.toolGestureActive = true;
    this.toolPointerId = e.pointerId;
    this.callbacks.getActiveTool().onPointerDown(info);
  };

  private onPointerMove = (e: PointerEvent): void => {
    if (this.pointers.has(e.pointerId)) {
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY, pointerType: e.pointerType });
    }

    if (this.pointers.size === 2) {
      this.updatePinch();
      return;
    }

    const info = this.toPointerInfo(e);

    if (this.middlePanning) {
      const dx = info.screenX - this.lastPanX;
      const dy = info.screenY - this.lastPanY;
      this.lastPanX = info.screenX;
      this.lastPanY = info.screenY;
      this.camera.panByScreenDelta(dx, dy);
      this.callbacks.requestRender();
      return;
    }

    if (this.toolGestureActive) {
      this.callbacks.getActiveTool().onPointerMove(info);
    }
  };

  private onPointerUp = (e: PointerEvent): void => {
    this.pointers.delete(e.pointerId);

    if (this.middlePanning) {
      this.middlePanning = false;
      this.canvasManager.canvas.style.cursor = this.spaceHeld ? 'grab' : '';
    }

    if (this.pointers.size < 2) {
      this.pinchStartDist = 0;
    }

    if (this.toolGestureActive && this.toolPointerId === e.pointerId) {
      const info = this.toPointerInfo(e);
      this.callbacks.getActiveTool().onPointerUp(info);
      this.toolGestureActive = false;
      this.toolPointerId = null;
    }
  };

  private startPinch(): void {
    const pts = Array.from(this.pointers.values());
    if (pts.length < 2) return;
    const [a, b] = pts;
    this.pinchStartDist = Math.hypot(a!.x - b!.x, a!.y - b!.y);
    this.pinchStartZoom = this.camera.zoom;
    this.lastPanX = (a!.x + b!.x) / 2;
    this.lastPanY = (a!.y + b!.y) / 2;
  }

  private updatePinch(): void {
    const pts = Array.from(this.pointers.values());
    if (pts.length < 2) return;
    const [a, b] = pts;
    const dist = Math.hypot(a!.x - b!.x, a!.y - b!.y);
    const midX = (a!.x + b!.x) / 2;
    const midY = (a!.y + b!.y) / 2;
    const rect = this.canvasManager.canvas.getBoundingClientRect();

    if (this.pinchStartDist > 0) {
      const scale = dist / this.pinchStartDist;
      this.camera.setZoomAt(midX - rect.left, midY - rect.top, this.pinchStartZoom * scale);
    }
    const dx = midX - this.lastPanX;
    const dy = midY - this.lastPanY;
    this.camera.panByScreenDelta(dx, dy);
    this.lastPanX = midX;
    this.lastPanY = midY;
    this.callbacks.requestRender();
  }

  private onWheel = (e: WheelEvent): void => {
    e.preventDefault();
    const rect = this.canvasManager.canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const factor = Math.exp(-e.deltaY * WHEEL_ZOOM_SENSITIVITY);
    this.camera.zoomAt(sx, sy, factor);
    this.callbacks.requestRender();
  };

  private onContextMenu = (e: MouseEvent): void => {
    e.preventDefault();
    this.callbacks.onContextMenu(e.clientX, e.clientY);
  };

  private onDoubleClick = (e: MouseEvent): void => {
    const rect = this.canvasManager.canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const world = this.camera.screenToWorld(sx, sy);
    const tool = this.callbacks.getActiveTool();
    tool.onDoubleClick?.({
      screenX: sx,
      screenY: sy,
      worldX: world.x,
      worldY: world.y,
      button: 0,
      shiftKey: e.shiftKey,
      altKey: e.altKey,
      ctrlKey: e.ctrlKey || e.metaKey,
      pointerType: 'mouse',
      pointerId: -1,
    });
  };

  private onKeyDown = (e: KeyboardEvent): void => {
    const tag = (document.activeElement?.tagName ?? '').toLowerCase();
    const isFormField = tag === 'input' || tag === 'textarea' || tag === 'select';

    if (e.code === 'Space' && !isFormField) {
      this.spaceHeld = true;
      if (!this.middlePanning) this.canvasManager.canvas.style.cursor = 'grab';
    }

    if (isFormField) return;

    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === 'z' && e.shiftKey) {
      e.preventDefault();
      this.callbacks.onRedo();
      return;
    }
    if (mod && e.key.toLowerCase() === 'z') {
      e.preventDefault();
      this.callbacks.onUndo();
      return;
    }
    if (mod && e.key.toLowerCase() === 'y') {
      e.preventDefault();
      this.callbacks.onRedo();
      return;
    }
    if (mod && e.key.toLowerCase() === 's') {
      e.preventDefault();
      this.callbacks.onSave();
      return;
    }
    if (mod && e.key.toLowerCase() === 'o') {
      e.preventDefault();
      this.callbacks.onOpen();
      return;
    }
    if (mod && e.key.toLowerCase() === 'c') {
      this.callbacks.onCopy();
      return;
    }
    if (mod && e.key.toLowerCase() === 'v') {
      this.callbacks.onPaste();
      return;
    }
    if (mod && e.key.toLowerCase() === 'd') {
      e.preventDefault();
      this.callbacks.onDuplicate();
      return;
    }
    if (mod && e.key.toLowerCase() === 'a') {
      e.preventDefault();
      this.callbacks.onSelectAll();
      return;
    }
    if (e.key === 'Delete' || e.key === 'Backspace') {
      if (this.callbacks.getActiveTool().onKeyDown?.(e)) {
        e.preventDefault();
        return;
      }
      this.callbacks.onDelete();
      return;
    }
    if (e.key === 'Escape') {
      this.callbacks.onEscape();
      return;
    }

    if (!this.callbacks.isTextEditing() && /^[a-z]$/i.test(e.key)) {
      this.callbacks.onToolShortcut(e.key.toLowerCase());
    }

    this.callbacks.getActiveTool().onKeyDown?.(e);
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    if (e.code === 'Space') {
      this.spaceHeld = false;
      if (!this.middlePanning) this.canvasManager.canvas.style.cursor = '';
    }
  };

  private resetTransientState = (): void => {
    this.spaceHeld = false;
    this.middlePanning = false;
    this.pointers.clear();
    this.pinchStartDist = 0;
  };

  dispose(): void {
    const canvas = this.canvasManager.canvas;
    canvas.removeEventListener('pointerdown', this.onPointerDown);
    canvas.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerup', this.onPointerUp);
    window.removeEventListener('pointercancel', this.onPointerUp);
    canvas.removeEventListener('wheel', this.onWheel);
    canvas.removeEventListener('contextmenu', this.onContextMenu);
    canvas.removeEventListener('dblclick', this.onDoubleClick);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.resetTransientState);
  }
}
