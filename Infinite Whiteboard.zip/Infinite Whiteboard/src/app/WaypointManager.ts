import type { Waypoint } from '@/models/Waypoint';
import { generateWaypointId, WAYPOINT_COLORS } from '@/models/Waypoint';
import type { Camera } from './Camera';

export type WaypointListener = () => void;

const JUMP_DURATION_MS = 300;

/** Named camera bookmarks. Jumping animates the camera with an ease-in-out
 * curve rather than snapping, per the design spec. */
export class WaypointManager {
  private waypoints: Map<string, Waypoint> = new Map();
  private listeners = new Set<WaypointListener>();

  constructor(private camera: Camera) {}

  onChange(fn: WaypointListener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private notify(): void {
    for (const fn of this.listeners) fn();
  }

  create(name: string, color?: string): Waypoint {
    const wp: Waypoint = {
      id: generateWaypointId(),
      name: name.trim() || `Waypoint ${this.waypoints.size + 1}`,
      x: this.camera.x,
      y: this.camera.y,
      zoom: this.camera.zoom,
      createdAt: Date.now(),
      color: color ?? WAYPOINT_COLORS[this.waypoints.size % WAYPOINT_COLORS.length],
    };
    this.waypoints.set(wp.id, wp);
    this.notify();
    return wp;
  }

  rename(id: string, name: string): void {
    const wp = this.waypoints.get(id);
    if (!wp) return;
    wp.name = name.trim() || wp.name;
    this.notify();
  }

  delete(id: string): void {
    if (this.waypoints.delete(id)) this.notify();
  }

  add(wp: Waypoint): void {
    this.waypoints.set(wp.id, wp);
    this.notify();
  }

  jumpTo(id: string, onDone?: () => void): void {
    const wp = this.waypoints.get(id);
    if (!wp) return;
    this.camera.animateTo({ x: wp.x, y: wp.y, zoom: wp.zoom }, JUMP_DURATION_MS, onDone);
  }

  get(id: string): Waypoint | undefined {
    return this.waypoints.get(id);
  }

  listSortedAlphabetically(): Waypoint[] {
    return Array.from(this.waypoints.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  serialize(): Waypoint[] {
    return Array.from(this.waypoints.values());
  }

  load(waypoints: Waypoint[]): void {
    this.waypoints.clear();
    for (const wp of waypoints) this.waypoints.set(wp.id, wp);
    this.notify();
  }

  clear(): void {
    this.waypoints.clear();
    this.notify();
  }
}
