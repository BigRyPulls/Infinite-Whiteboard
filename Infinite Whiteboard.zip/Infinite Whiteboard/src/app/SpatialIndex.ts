export interface AABB {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

function intersects(a: AABB, b: AABB): boolean {
  return a.minX <= b.maxX && a.maxX >= b.minX && a.minY <= b.maxY && a.maxY >= b.minY;
}

function contains(outer: AABB, inner: AABB): boolean {
  return inner.minX >= outer.minX && inner.maxX <= outer.maxX && inner.minY >= outer.minY && inner.maxY <= outer.maxY;
}

const MAX_ITEMS_PER_NODE = 16;
const MAX_DEPTH = 12;

class QuadNode {
  bounds: AABB;
  depth: number;
  items: Map<string, AABB> = new Map();
  children: [QuadNode, QuadNode, QuadNode, QuadNode] | null = null;

  constructor(bounds: AABB, depth: number) {
    this.bounds = bounds;
    this.depth = depth;
  }

  split(): void {
    const { minX, minY, maxX, maxY } = this.bounds;
    const midX = (minX + maxX) / 2;
    const midY = (minY + maxY) / 2;
    const d = this.depth + 1;
    this.children = [
      new QuadNode({ minX, minY, maxX: midX, maxY: midY }, d),
      new QuadNode({ minX: midX, minY, maxX, maxY: midY }, d),
      new QuadNode({ minX, minY: midY, maxX: midX, maxY }, d),
      new QuadNode({ minX: midX, minY: midY, maxX, maxY }, d),
    ];
  }
}

/**
 * A dynamically-growing quadtree over an infinite world. The root doubles
 * in size (re-rooting with the old root as one quadrant) whenever an
 * element falls outside current bounds, so there is no hard world limit.
 * Items are "loose": they live in the deepest node whose bounds fully
 * contain their AABB, which keeps updates cheap and queries correct
 * without needing to split across node boundaries.
 */
export class SpatialIndex {
  private root: QuadNode;
  private locations = new Map<string, QuadNode>();
  private boundsById = new Map<string, AABB>();

  constructor(initialHalfSize = 4096) {
    this.root = new QuadNode(
      { minX: -initialHalfSize, minY: -initialHalfSize, maxX: initialHalfSize, maxY: initialHalfSize },
      0
    );
  }

  clear(): void {
    this.root = new QuadNode(this.root.bounds, 0);
    this.locations.clear();
    this.boundsById.clear();
  }

  insert(id: string, bounds: AABB): void {
    this.ensureRootContains(bounds);
    this.boundsById.set(id, bounds);
    const node = this.insertIntoNode(this.root, id, bounds);
    this.locations.set(id, node);
  }

  remove(id: string): void {
    const node = this.locations.get(id);
    if (node) {
      node.items.delete(id);
      this.locations.delete(id);
    }
    this.boundsById.delete(id);
  }

  update(id: string, bounds: AABB): void {
    this.remove(id);
    this.insert(id, bounds);
  }

  getBounds(id: string): AABB | undefined {
    return this.boundsById.get(id);
  }

  /** Returns ids of all items whose AABB intersects the query rect. */
  query(rect: AABB, out: string[] = []): string[] {
    this.queryNode(this.root, rect, out);
    return out;
  }

  size(): number {
    return this.boundsById.size;
  }

  private queryNode(node: QuadNode, rect: AABB, out: string[]): void {
    if (!intersects(node.bounds, rect)) return;
    for (const [id, bounds] of node.items) {
      if (intersects(bounds, rect)) out.push(id);
    }
    if (node.children) {
      for (const child of node.children) this.queryNode(child, rect, out);
    }
  }

  private ensureRootContains(bounds: AABB): void {
    let guard = 0;
    while (!contains(this.root.bounds, bounds) && guard < 64) {
      guard += 1;
      this.growRoot(bounds);
    }
  }

  /** Doubles the root size in the direction needed to include `bounds`,
   * re-parenting the existing tree as one quadrant of the new root. */
  private growRoot(bounds: AABB): void {
    const old = this.root;
    const { minX, minY, maxX, maxY } = old.bounds;
    const w = maxX - minX;
    const h = maxY - minY;

    const growLeft = bounds.minX < minX;
    const growUp = bounds.minY < minY;

    const newBounds: AABB = growLeft
      ? growUp
        ? { minX: minX - w, minY: minY - h, maxX, maxY }
        : { minX: minX - w, minY, maxX, maxY: maxY + h }
      : growUp
      ? { minX, minY: minY - h, maxX: maxX + w, maxY }
      : { minX, minY, maxX: maxX + w, maxY: maxY + h };

    const newRoot = new QuadNode(newBounds, 0);
    newRoot.split();
    const children = newRoot.children!;
    // Slot the old root into whichever new quadrant matches its bounds.
    const slot = children.find(
      (c) => c.bounds.minX === minX && c.bounds.minY === minY && c.bounds.maxX === maxX && c.bounds.maxY === maxY
    );
    if (slot) {
      old.depth = slot.depth;
      this.reparentDepths(old, slot.depth);
      const idx = children.indexOf(slot);
      children[idx] = old;
    }
    this.root = newRoot;
    // Locations map entries remain valid since node references are preserved.
  }

  private reparentDepths(node: QuadNode, depth: number): void {
    node.depth = depth;
    if (node.children) {
      for (const child of node.children) this.reparentDepths(child, depth + 1);
    }
  }

  private insertIntoNode(node: QuadNode, id: string, bounds: AABB): QuadNode {
    if (node.children) {
      for (const child of node.children) {
        if (contains(child.bounds, bounds)) {
          return this.insertIntoNode(child, id, bounds);
        }
      }
      node.items.set(id, bounds);
      return node;
    }

    if (node.items.size < MAX_ITEMS_PER_NODE || node.depth >= MAX_DEPTH) {
      node.items.set(id, bounds);
      return node;
    }

    node.split();
    const existing = Array.from(node.items.entries());
    node.items.clear();
    for (const [existingId, existingBounds] of existing) {
      const target = this.insertIntoNode(node, existingId, existingBounds);
      this.locations.set(existingId, target);
    }
    return this.insertIntoNode(node, id, bounds);
  }
}
