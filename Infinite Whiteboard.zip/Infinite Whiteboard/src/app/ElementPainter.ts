import type { BoardElement, ImageElement, ShapeElement, StrokeElement, TextElement } from '@/models/Element';
import type { ImageLoader } from './ImageLoader';

/**
 * Pure element -> Canvas2D painting logic shared by the live Renderer and
 * the PNG ExportManager, so raster output always matches what's on
 * screen. Assumes the canvas transform is already set up so drawing
 * happens directly in world coordinates.
 */
export function paintElement(ctx: CanvasRenderingContext2D, el: BoardElement, imageLoader: ImageLoader): void {
  ctx.save();
  ctx.globalAlpha = el.opacity;

  const cx = el.x + (el.width * el.scaleX) / 2;
  const cy = el.y + (el.height * el.scaleY) / 2;
  if (el.rotation !== 0) {
    ctx.translate(cx, cy);
    ctx.rotate(el.rotation);
    ctx.translate(-cx, -cy);
  }

  switch (el.type) {
    case 'stroke':
      paintStroke(ctx, el);
      break;
    case 'text':
      paintText(ctx, el);
      break;
    case 'image':
      paintImage(ctx, el, imageLoader);
      break;
    case 'shape':
      paintShape(ctx, el);
      break;
  }

  ctx.restore();
}

function paintStroke(ctx: CanvasRenderingContext2D, el: StrokeElement): void {
  const pts = el.points;
  if (pts.length < 2) {
    if (pts.length === 1) {
      ctx.fillStyle = el.color;
      ctx.beginPath();
      ctx.arc(pts[0]!.x, pts[0]!.y, el.size / 2, 0, Math.PI * 2);
      ctx.fill();
    }
    return;
  }
  ctx.strokeStyle = el.color;
  ctx.lineWidth = el.size;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(pts[0]!.x, pts[0]!.y);
  for (let i = 1; i < pts.length - 1; i++) {
    const p0 = pts[i]!;
    const p1 = pts[i + 1]!;
    if (p0.newSubpath) {
      ctx.moveTo(p0.x, p0.y);
      continue;
    }
    const midX = (p0.x + p1.x) / 2;
    const midY = (p0.y + p1.y) / 2;
    ctx.quadraticCurveTo(p0.x, p0.y, midX, midY);
  }
  const last = pts[pts.length - 1]!;
  if (last.newSubpath) ctx.moveTo(last.x, last.y);
  else ctx.lineTo(last.x, last.y);
  ctx.stroke();
}

function paintText(ctx: CanvasRenderingContext2D, el: TextElement): void {
  const weight = el.bold ? 'bold' : 'normal';
  const style = el.italic ? 'italic' : 'normal';
  ctx.font = `${style} ${weight} ${el.fontSize}px ${el.fontFamily}`;
  ctx.fillStyle = el.color;
  ctx.textBaseline = 'top';
  ctx.textAlign = el.align;

  const lines = el.text.split('\n');
  const lineHeight = el.fontSize * el.lineHeight;
  let anchorX = el.x;
  if (el.align === 'center') anchorX = el.x + (el.width * el.scaleX) / 2;
  if (el.align === 'right') anchorX = el.x + el.width * el.scaleX;

  for (let i = 0; i < lines.length; i++) {
    ctx.fillText(lines[i]!, anchorX, el.y + i * lineHeight);
  }
}

function paintImage(ctx: CanvasRenderingContext2D, el: ImageElement, imageLoader: ImageLoader): void {
  const entry = imageLoader.get(el.src);
  const w = el.width * el.scaleX;
  const h = el.height * el.scaleY;
  if (!entry) {
    imageLoader.load(el.src).catch(() => undefined);
    return;
  }
  ctx.drawImage(entry.image, el.x, el.y, w, h);
}

function paintShape(ctx: CanvasRenderingContext2D, el: ShapeElement): void {
  const w = el.width * el.scaleX;
  const h = el.height * el.scaleY;
  ctx.lineWidth = el.strokeWidth;
  ctx.strokeStyle = el.strokeColor;
  if (el.fillColor) ctx.fillStyle = el.fillColor;

  ctx.beginPath();
  switch (el.shape) {
    case 'rectangle':
      ctx.rect(el.x, el.y, w, h);
      break;
    case 'ellipse':
      ctx.ellipse(el.x + w / 2, el.y + h / 2, Math.abs(w / 2), Math.abs(h / 2), 0, 0, Math.PI * 2);
      break;
    case 'line':
      ctx.moveTo(el.x, el.y);
      ctx.lineTo(el.x + w, el.y + h);
      break;
    case 'arrow': {
      ctx.moveTo(el.x, el.y);
      ctx.lineTo(el.x + w, el.y + h);
      const angle = Math.atan2(h, w);
      const headLen = Math.max(10, el.strokeWidth * 4);
      const ex = el.x + w;
      const ey = el.y + h;
      ctx.moveTo(ex - headLen * Math.cos(angle - Math.PI / 6), ey - headLen * Math.sin(angle - Math.PI / 6));
      ctx.lineTo(ex, ey);
      ctx.lineTo(ex - headLen * Math.cos(angle + Math.PI / 6), ey - headLen * Math.sin(angle + Math.PI / 6));
      break;
    }
  }
  if (el.fillColor && (el.shape === 'rectangle' || el.shape === 'ellipse')) ctx.fill();
  ctx.stroke();
}
