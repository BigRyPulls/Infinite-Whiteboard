import { type BoardFile, BOARD_FORMAT_VERSION, createEmptyBoard } from '@/models/Board';

const AUTOSAVE_KEY = 'iw_autosave_v1';
const RECENT_KEY = 'iw_recent_files_v1';
const AUTOSAVE_INTERVAL_MS = 30_000;
const MAX_RECENT = 8;

export interface RecentFileEntry {
  name: string;
  savedAt: number;
}

export type SaveSource = () => BoardFile;
export type LoadSink = (board: BoardFile) => void;
export type NotifyFn = (message: string, kind?: 'info' | 'error' | 'warn') => void;

/**
 * Handles all persistence: periodic + pre-unload autosave to
 * localStorage, explicit JSON export/import (via the File System Access
 * API when available, falling back to anchor-download / file-input for
 * broad browser support), and crash recovery.
 */
export class StorageManager {
  private autosaveTimer: number | null = null;

  constructor(private getBoard: SaveSource, private applyBoard: LoadSink, private notify: NotifyFn) {}

  startAutosave(): void {
    this.stopAutosave();
    this.autosaveTimer = window.setInterval(() => this.autosaveNow(), AUTOSAVE_INTERVAL_MS);
    window.addEventListener('beforeunload', this.handleBeforeUnload);
  }

  stopAutosave(): void {
    if (this.autosaveTimer !== null) {
      window.clearInterval(this.autosaveTimer);
      this.autosaveTimer = null;
    }
    window.removeEventListener('beforeunload', this.handleBeforeUnload);
  }

  private handleBeforeUnload = (): void => {
    this.autosaveNow();
  };

  autosaveNow(): void {
    try {
      const board = this.getBoard();
      localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(board));
    } catch (err) {
      console.warn('Autosave failed', err);
      this.notify('Autosave failed — storage may be full.', 'warn');
    }
  }

  /** Returns the autosaved board if one exists and is well-formed. */
  peekAutosave(): BoardFile | null {
    const raw = localStorage.getItem(AUTOSAVE_KEY);
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      if (!this.isValidBoard(parsed)) return null;
      return parsed;
    } catch {
      return null;
    }
  }

  clearAutosave(): void {
    localStorage.removeItem(AUTOSAVE_KEY);
  }

  private isValidBoard(value: unknown): value is BoardFile {
    if (!value || typeof value !== 'object') return false;
    const v = value as Record<string, unknown>;
    return (
      typeof v.formatVersion === 'number' &&
      typeof v.camera === 'object' &&
      Array.isArray(v.elements) &&
      Array.isArray(v.waypoints)
    );
  }

  async saveToFile(suggestedName = 'board.json'): Promise<void> {
    const board = this.getBoard();
    board.formatVersion = BOARD_FORMAT_VERSION;
    board.metadata.updatedAt = Date.now();
    const json = JSON.stringify(board);

    try {
      const withPicker = window as unknown as {
        showSaveFilePicker?: (opts: unknown) => Promise<{ createWritable: () => Promise<FileSystemWritableFileStream> }>;
      };
      if (withPicker.showSaveFilePicker) {
        const handle = await withPicker.showSaveFilePicker({
          suggestedName,
          types: [{ description: 'Whiteboard JSON', accept: { 'application/json': ['.json'] } }],
        });
        const writable = await handle.createWritable();
        await writable.write(json);
        await writable.close();
        this.pushRecent(suggestedName);
        this.notify(`Saved ${suggestedName}`, 'info');
        return;
      }
    } catch (err) {
      if ((err as DOMException)?.name === 'AbortError') return;
      console.warn('showSaveFilePicker failed, falling back to download', err);
    }

    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = suggestedName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    this.pushRecent(suggestedName);
    this.notify(`Downloaded ${suggestedName}`, 'info');
  }

  async loadFromFile(): Promise<void> {
    try {
      const withPicker = window as unknown as {
        showOpenFilePicker?: (opts: unknown) => Promise<{ getFile: () => Promise<File> }[]>;
      };
      if (withPicker.showOpenFilePicker) {
        const [handle] = await withPicker.showOpenFilePicker({
          types: [{ description: 'Whiteboard JSON', accept: { 'application/json': ['.json'] } }],
        });
        if (!handle) return;
        const file = await handle.getFile();
        await this.loadFile(file);
        return;
      }
    } catch (err) {
      if ((err as DOMException)?.name === 'AbortError') return;
      console.warn('showOpenFilePicker failed, falling back to input', err);
    }

    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json,.json';
    input.addEventListener('change', () => {
      const file = input.files?.[0];
      if (file) void this.loadFile(file);
    });
    input.click();
  }

  async loadFile(file: File): Promise<void> {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!this.isValidBoard(parsed)) {
        this.notify('That file is not a valid board (corrupt or unsupported format).', 'error');
        return;
      }
      this.applyBoard(parsed);
      this.pushRecent(file.name);
      this.notify(`Loaded ${file.name}`, 'info');
    } catch (err) {
      console.error(err);
      this.notify('Failed to read board file — it may be corrupted.', 'error');
    }
  }

  newBoard(): BoardFile {
    return createEmptyBoard();
  }

  private pushRecent(name: string): void {
    const list = this.getRecent().filter((r) => r.name !== name);
    list.unshift({ name, savedAt: Date.now() });
    localStorage.setItem(RECENT_KEY, JSON.stringify(list.slice(0, MAX_RECENT)));
  }

  getRecent(): RecentFileEntry[] {
    try {
      const raw = localStorage.getItem(RECENT_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
}
