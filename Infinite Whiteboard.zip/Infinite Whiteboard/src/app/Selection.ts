import type { Scene } from './Scene';
import { getElementBounds } from '@/models/Element';
import type { AABB } from './SpatialIndex';

export type SelectionListener = () => void;

/** Tracks which elements are currently selected. Pure state — the actual
 * drag/resize/rotate interactions live in SelectionTool. */
export class Selection {
  private ids = new Set<string>();
  private listeners = new Set<SelectionListener>();

  onChange(fn: SelectionListener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private notify(): void {
    for (const fn of this.listeners) fn();
  }

  get size(): number {
    return this.ids.size;
  }

  get ids_(): ReadonlySet<string> {
    return this.ids;
  }

  isSelected(id: string): boolean {
    return this.ids.has(id);
  }

  getIds(): string[] {
    return Array.from(this.ids);
  }

  set(ids: string[]): void {
    this.ids = new Set(ids);
    this.notify();
  }

  add(id: string): void {
    this.ids.add(id);
    this.notify();
  }

  toggle(id: string): void {
    if (this.ids.has(id)) this.ids.delete(id);
    else this.ids.add(id);
    this.notify();
  }

  remove(id: string): void {
    if (this.ids.delete(id)) this.notify();
  }

  clear(): void {
    if (this.ids.size === 0) return;
    this.ids.clear();
    this.notify();
  }

  getBounds(scene: Scene): AABB | null {
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let found = false;
    for (const id of this.ids) {
      const el = scene.getElement(id);
      if (!el) continue;
      found = true;
      const b = getElementBounds(el);
      minX = Math.min(minX, b.minX);
      minY = Math.min(minY, b.minY);
      maxX = Math.max(maxX, b.maxX);
      maxY = Math.max(maxY, b.maxY);
    }
    return found ? { minX, minY, maxX, maxY } : null;
  }
}
