import { CanvasManager } from './CanvasManager';
import { Camera } from './Camera';
import { Scene } from './Scene';
import { Selection } from './Selection';
import { History, AddElementsCommand } from './History';
import { ImageLoader } from './ImageLoader';
import { Renderer, type RenderSettings } from './Renderer';
import { WaypointManager } from './WaypointManager';
import { StorageManager } from './StorageManager';
import { ExportManager, type ExportScope } from './ExportManager';
import { Input } from './Input';
import { UI } from '@/ui/UI';

import { PanTool } from '@/tools/PanTool';
import { SelectionTool } from '@/tools/SelectionTool';
import { BrushTool } from '@/tools/BrushTool';
import { TextTool } from '@/tools/TextTool';
import { ShapeTool } from '@/tools/ShapeTool';
import { ImageTool } from '@/tools/ImageTool';
import type { Tool, ToolContext, ToolId } from '@/tools/Tool';

import type { BoardElement } from '@/models/Element';
import { createEmptyBoard, type BoardFile } from '@/models/Board';

export type NotifyKind = 'info' | 'error' | 'warn';
export type NotifyListener = (message: string, kind: NotifyKind) => void;

const GRID_SNAP_SIZE = 10;

/**
 * Composition root: owns every subsystem and wires them together. Keeps
 * the render loop lean by only repainting when something actually
 * changed (scene mutation, camera movement/animation, or a tool overlay
 * request) instead of redrawing unconditionally every frame.
 */
export class App {
  readonly canvasManager: CanvasManager;
  readonly camera = new Camera();
  readonly scene = new Scene();
  readonly selection = new Selection();
  readonly history = new History();
  readonly imageLoader = new ImageLoader();
  readonly waypoints: WaypointManager;
  readonly storage: StorageManager;
  readonly exporter: ExportManager;
  readonly renderer: Renderer;
  readonly input: Input;
  readonly ui: UI;

  readonly renderSettings: RenderSettings = { showGrid: true };
  snapEnabled = false;

  readonly tools: Record<ToolId, Tool>;
  activeToolId: ToolId = 'select';

  private clipboard: BoardElement[] = [];
  private needsRender = true;
  private lastMouseWorld = { x: 0, y: 0 };
  private fps = 60;
  private frameTimes: number[] = [];
  private notifyListeners = new Set<NotifyListener>();
  private boardName = 'Untitled Board';
  private rafHandle = 0;

  constructor(canvas: HTMLCanvasElement, uiRoot: HTMLElement) {
    this.canvasManager = new CanvasManager(canvas);
    this.canvasManager.onResize((w, h) => {
      this.camera.setViewportSize(w, h);
      this.requestRender();
    });
    this.camera.setViewportSize(this.canvasManager.width, this.canvasManager.height);

    this.waypoints = new WaypointManager(this.camera);
    this.storage = new StorageManager(
      () => this.serializeBoard(),
      (board) => this.loadBoard(board),
      (msg, kind) => this.notify(msg, kind)
    );
    this.exporter = new ExportManager(this.scene, this.camera, this.imageLoader);

    this.renderer = new Renderer(
      this.canvasManager,
      this.camera,
      this.scene,
      this.selection,
      this.imageLoader,
      this.renderSettings,
      () => this.requestRender()
    );

    this.camera.onChange(() => this.requestRender());
    this.scene.onChange(() => this.requestRender());
    this.selection.onChange(() => this.requestRender());

    const toolContext: ToolContext = {
      scene: this.scene,
      selection: this.selection,
      history: this.history,
      camera: this.camera,
      imageLoader: this.imageLoader,
      requestRender: () => this.requestRender(),
      setCursor: (cursor) => (this.canvasManager.canvas.style.cursor = cursor),
      setHiddenElement: (id) => this.renderer.setHiddenElement(id),
      notify: (msg, kind) => this.notify(msg, kind),
      getSnapEnabled: () => this.snapEnabled,
      snapValue: (v) => (this.snapEnabled ? Math.round(v / GRID_SNAP_SIZE) * GRID_SNAP_SIZE : v),
      uiRoot,
      editTextElement: (el) => this.textTool.editElement(el),
      openContextMenu: (x, y) => this.ui.openContextMenuAt(x, y),
    };

    const selectTool = new SelectionTool(toolContext);
    const panTool = new PanTool(toolContext);
    const brushTool = new BrushTool(toolContext);
    const textTool = new TextTool(toolContext);
    const shapeTool = new ShapeTool(toolContext);
    const imageTool = new ImageTool(toolContext);

    this.tools = {
      select: selectTool,
      pan: panTool,
      brush: brushTool,
      text: textTool,
      shape: shapeTool,
      image: imageTool,
    };
    this.tools.select.onActivate?.();

    this.input = new Input(this.canvasManager, this.camera, {
      getActiveTool: () => this.tools[this.activeToolId],
      requestRender: () => this.requestRender(),
      onUndo: () => this.undo(),
      onRedo: () => this.redo(),
      onSave: () => void this.storage.saveToFile(this.suggestedFileName()),
      onOpen: () => void this.storage.loadFromFile(),
      onCopy: () => this.copySelection(),
      onPaste: () => this.pasteClipboard(),
      onDuplicate: () => this.selectionTool.duplicateSelection(),
      onDelete: () => this.selectionTool.deleteSelection(),
      onEscape: () => this.handleEscape(),
      onContextMenu: (x, y) => this.ui.openContextMenuAt(x, y),
      onSelectAll: () => this.selection.set(this.scene.getAll().map((e) => e.id)),
      isTextEditing: () => this.textTool.isEditing(),
      onToolShortcut: (key) => this.handleToolShortcut(key),
    });

    document.addEventListener('paste', (e) => this.handleNativePaste(e));
    document.addEventListener('drop', (e) => this.handleDrop(e));
    document.addEventListener('dragover', (e) => e.preventDefault());

    this.ui = new UI(this, uiRoot);

    this.boot();
    this.startLoop();
  }

  get selectionTool(): SelectionTool {
    return this.tools.select as SelectionTool;
  }
  get brushTool(): BrushTool {
    return this.tools.brush as BrushTool;
  }
  get textTool(): TextTool {
    return this.tools.text as TextTool;
  }
  get shapeTool(): ShapeTool {
    return this.tools.shape as ShapeTool;
  }
  get imageTool(): ImageTool {
    return this.tools.image as ImageTool;
  }

  private boot(): void {
    const recovered = this.storage.peekAutosave();
    if (recovered && recovered.elements.length > 0) {
      this.ui.promptRecovery(recovered);
    } else {
      this.newBoard();
    }
    this.storage.startAutosave();
  }

  setActiveTool(id: ToolId): void {
    if (this.activeToolId === id) return;
    this.tools[this.activeToolId].onDeactivate?.();
    this.activeToolId = id;
    this.tools[id].onActivate?.();
    this.requestRender();
    this.ui.refreshAll();
  }

  private static readonly TOOL_SHORTCUTS: Record<string, ToolId> = {
    v: 'select',
    b: 'brush',
    t: 'text',
    s: 'shape',
    h: 'pan',
  };

  private handleToolShortcut(key: string): void {
    const id = App.TOOL_SHORTCUTS[key];
    if (id) this.setActiveTool(id);
  }

  requestRender(): void {
    this.needsRender = true;
  }

  onNotify(fn: NotifyListener): () => void {
    this.notifyListeners.add(fn);
    return () => this.notifyListeners.delete(fn);
  }

  notify(message: string, kind: NotifyKind = 'info'): void {
    for (const fn of this.notifyListeners) fn(message, kind);
  }

  trackMouseWorld(x: number, y: number): void {
    this.lastMouseWorld = { x, y };
  }
  getMouseWorld(): { x: number; y: number } {
    return this.lastMouseWorld;
  }
  getFps(): number {
    return this.fps;
  }

  getMemoryEstimateBytes(): number {
    let bytes = 0;
    for (const el of this.scene.getAll()) {
      bytes += 256;
      if (el.type === 'stroke') bytes += el.points.length * 24;
      if (el.type === 'text') bytes += el.text.length * 2;
    }
    bytes += this.imageLoader.estimateBytes();
    return bytes;
  }

  // ---- history -------------------------------------------------------------

  undo(): void {
    if (this.textTool.isEditing()) return;
    this.history.undo();
    this.requestRender();
    this.ui.refreshAll();
  }

  redo(): void {
    if (this.textTool.isEditing()) return;
    this.history.redo();
    this.requestRender();
    this.ui.refreshAll();
  }

  // ---- clipboard -------------------------------------------------------------

  hasClipboardContent(): boolean {
    return this.clipboard.length > 0;
  }

  copySelection(): void {
    const ids = this.selection.getIds();
    if (ids.length === 0) return;
    this.clipboard = ids.map((id) => structuredClone(this.scene.getElement(id)!));
    this.notify(`Copied ${ids.length} object${ids.length > 1 ? 's' : ''}`, 'info');
  }

  pasteClipboard(): void {
    if (this.clipboard.length === 0) return;
    const clones = this.clipboard.map((el) => {
      const clone = structuredClone(el);
      clone.id = `${el.type}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
      clone.x += 24;
      clone.y += 24;
      clone.layer = this.scene.allocateLayer();
      return clone;
    });
    this.history.push(new AddElementsCommand(this.scene, clones));
    this.selection.set(clones.map((c) => c.id));
    this.requestRender();
  }

  private async handleNativePaste(e: ClipboardEvent): Promise<void> {
    const tag = (document.activeElement?.tagName ?? '').toLowerCase();
    if (tag === 'input' || tag === 'textarea') return;
    const items = e.clipboardData?.items;
    if (!items) return;
    const imageFiles: File[] = [];
    for (const item of items) {
      if (item.type.startsWith('image/')) {
        const file = item.getAsFile();
        if (file) imageFiles.push(file);
      }
    }
    if (imageFiles.length > 0) {
      e.preventDefault();
      const center = this.camera.screenToWorld(this.canvasManager.width / 2, this.canvasManager.height / 2);
      await this.imageTool.importFiles(imageFiles, center);
    }
  }

  private handleDrop(e: DragEvent): void {
    e.preventDefault();
    const files = e.dataTransfer?.files;
    if (!files || files.length === 0) return;
    const rect = this.canvasManager.canvas.getBoundingClientRect();
    const world = this.camera.screenToWorld(e.clientX - rect.left, e.clientY - rect.top);
    void this.imageTool.importFiles(files, world);
  }

  private handleEscape(): void {
    if (this.textTool.isEditing()) {
      this.textTool.commitEdit();
      return;
    }
    this.selection.clear();
    this.ui.closeContextMenu();
  }

  // ---- board lifecycle -------------------------------------------------------------

  newBoard(): void {
    this.scene.clear();
    this.selection.clear();
    this.history.clear();
    this.waypoints.clear();
    this.camera.setState({ x: 0, y: 0, zoom: 1 });
    this.boardName = 'Untitled Board';
    this.ui.refreshAll();
    this.requestRender();
  }

  serializeBoard(): BoardFile {
    const board = createEmptyBoard(this.boardName);
    board.camera = this.camera.getState();
    board.elements = this.scene.getAllSortedByLayer();
    board.waypoints = this.waypoints.serialize();
    return board;
  }

  loadBoard(board: BoardFile): void {
    try {
      this.scene.loadElements(board.elements ?? []);
      this.waypoints.load(board.waypoints ?? []);
      this.camera.setState(board.camera ?? { x: 0, y: 0, zoom: 1 });
      this.boardName = board.metadata?.name ?? 'Untitled Board';
      this.selection.clear();
      this.history.clear();
      for (const el of this.scene.getAll()) {
        if (el.type === 'image') void this.imageLoader.load(el.src);
      }
      this.ui.refreshAll();
      this.requestRender();
    } catch (err) {
      console.error(err);
      this.notify('Failed to restore board — file may be corrupt.', 'error');
    }
  }

  suggestedFileName(): string {
    return `${this.boardName.replace(/[^a-z0-9-_ ]/gi, '').trim() || 'board'}.json`;
  }

  exportBoard(scope: ExportScope, format: 'png' | 'svg' | 'json'): void {
    if (format === 'png') this.exporter.exportPNG(scope);
    else if (format === 'svg') this.exporter.exportSVG(scope);
    else void this.storage.saveToFile(this.suggestedFileName());
  }

  // ---- render loop -------------------------------------------------------------

  private startLoop(): void {
    const step = (now: number) => {
      const animating = this.camera.tick(now);
      if (animating) this.needsRender = true;

      this.frameTimes.push(now);
      while (this.frameTimes.length > 0 && now - this.frameTimes[0]! > 500) this.frameTimes.shift();
      if (this.frameTimes.length > 1) {
        const span = now - this.frameTimes[0]!;
        this.fps = span > 0 ? Math.round(((this.frameTimes.length - 1) * 1000) / span) : 60;
      }

      if (this.needsRender) {
        this.needsRender = false;
        const tool = this.tools[this.activeToolId];
        this.renderer.render((ctx) => tool.renderOverlay?.(ctx));
        this.scene.clearDirty();
      }

      this.ui.tickStatusBar();
      this.rafHandle = requestAnimationFrame(step);
    };
    this.rafHandle = requestAnimationFrame(step);
  }

  dispose(): void {
    cancelAnimationFrame(this.rafHandle);
    this.input.dispose();
    this.canvasManager.dispose();
    this.storage.stopAutosave();
  }
}
