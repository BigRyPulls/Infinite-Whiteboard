import type { Scene } from './Scene';
import type { Camera } from './Camera';
import type { ImageLoader } from './ImageLoader';
import { paintElement } from './ElementPainter';
import { getElementBounds, type BoardElement } from '@/models/Element';

export type ExportScope = 'viewport' | 'board';

const BG_COLOR = '#0a0d10';

function computeBoardBounds(scene: Scene): { minX: number; minY: number; maxX: number; maxY: number } | null {
  const elements = scene.getAll();
  if (elements.length === 0) return null;
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const el of elements) {
    const b = getElementBounds(el);
    minX = Math.min(minX, b.minX);
    minY = Math.min(minY, b.minY);
    maxX = Math.max(maxX, b.maxX);
    maxY = Math.max(maxY, b.maxY);
  }
  return { minX, minY, maxX, maxY };
}

function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/** Rasterizes the board (viewport or full extent) to PNG, or serializes
 * it to a lightweight SVG document. Both paths reuse the same painter
 * used for live rendering so exports match what's on screen. */
export class ExportManager {
  constructor(private scene: Scene, private camera: Camera, private imageLoader: ImageLoader) {}

  exportPNG(scope: ExportScope, padding = 40, pixelScale = 2): void {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let minX: number, minY: number, maxX: number, maxY: number;

    if (scope === 'viewport') {
      const rect = this.camera.getVisibleWorldRect();
      minX = rect.minX;
      minY = rect.minY;
      maxX = rect.maxX;
      maxY = rect.maxY;
    } else {
      const bounds = computeBoardBounds(this.scene);
      if (!bounds) {
        minX = -400;
        minY = -300;
        maxX = 400;
        maxY = 300;
      } else {
        minX = bounds.minX - padding;
        minY = bounds.minY - padding;
        maxX = bounds.maxX + padding;
        maxY = bounds.maxY + padding;
      }
    }

    const worldW = Math.max(1, maxX - minX);
    const worldH = Math.max(1, maxY - minY);
    canvas.width = Math.round(worldW * pixelScale);
    canvas.height = Math.round(worldH * pixelScale);

    ctx.fillStyle = BG_COLOR;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.scale(pixelScale, pixelScale);
    ctx.translate(-minX, -minY);

    const elements = this.scene.getAllSortedByLayer().filter((el) => {
      const b = getElementBounds(el);
      return b.maxX >= minX && b.minX <= maxX && b.maxY >= minY && b.minY <= maxY;
    });

    for (const el of elements) {
      if (!el.visible) continue;
      paintElement(ctx, el, this.imageLoader);
    }
    ctx.restore();

    canvas.toBlob((blob) => {
      if (blob) downloadBlob(blob, `whiteboard-${Date.now()}.png`);
    }, 'image/png');
  }

  exportSVG(scope: ExportScope, padding = 40): void {
    let minX: number, minY: number, maxX: number, maxY: number;

    if (scope === 'viewport') {
      const rect = this.camera.getVisibleWorldRect();
      ({ minX, minY, maxX, maxY } = rect);
    } else {
      const bounds = computeBoardBounds(this.scene);
      if (!bounds) {
        minX = -400;
        minY = -300;
        maxX = 400;
        maxY = 300;
      } else {
        minX = bounds.minX - padding;
        minY = bounds.minY - padding;
        maxX = bounds.maxX + padding;
        maxY = bounds.maxY + padding;
      }
    }

    const w = maxX - minX;
    const h = maxY - minY;
    const elements = this.scene.getAllSortedByLayer().filter((el) => el.visible);
    const body = elements.map((el) => this.elementToSvg(el)).join('\n  ');

    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="${minX} ${minY} ${w} ${h}">
  <rect x="${minX}" y="${minY}" width="${w}" height="${h}" fill="${BG_COLOR}" />
  ${body}
</svg>`;

    downloadBlob(new Blob([svg], { type: 'image/svg+xml' }), `whiteboard-${Date.now()}.svg`);
  }

  private elementToSvg(el: BoardElement): string {
    const transformParts: string[] = [];
    if (el.rotation !== 0) {
      const cx = el.x + (el.width * el.scaleX) / 2;
      const cy = el.y + (el.height * el.scaleY) / 2;
      transformParts.push(`rotate(${(el.rotation * 180) / Math.PI} ${cx} ${cy})`);
    }
    const transform = transformParts.length ? ` transform="${transformParts.join(' ')}"` : '';
    const opacity = el.opacity !== 1 ? ` opacity="${el.opacity}"` : '';

    switch (el.type) {
      case 'stroke': {
        if (el.points.length < 2) return '';
        let d = `M ${el.points[0]!.x} ${el.points[0]!.y}`;
        for (let i = 1; i < el.points.length; i++) {
          const p = el.points[i]!;
          d += p.newSubpath ? ` M ${p.x} ${p.y}` : ` L ${p.x} ${p.y}`;
        }
        return `<path d="${d}" fill="none" stroke="${el.color}" stroke-width="${el.size}" stroke-linecap="round" stroke-linejoin="round"${opacity}${transform} />`;
      }
      case 'text': {
        const weight = el.bold ? 'bold' : 'normal';
        const style = el.italic ? 'italic' : 'normal';
        const lines = el.text.split('\n');
        const lineHeight = el.fontSize * el.lineHeight;
        const tspans = lines
          .map((line, i) => `<tspan x="${el.x}" y="${el.y + el.fontSize + i * lineHeight}">${escapeXml(line)}</tspan>`)
          .join('');
        return `<text font-family="${escapeXml(el.fontFamily)}" font-size="${el.fontSize}" font-weight="${weight}" font-style="${style}" fill="${el.color}" text-anchor="${
          el.align === 'center' ? 'middle' : el.align === 'right' ? 'end' : 'start'
        }"${opacity}${transform}>${tspans}</text>`;
      }
      case 'shape': {
        const w = el.width * el.scaleX;
        const h = el.height * el.scaleY;
        const fill = el.fillColor ?? 'none';
        if (el.shape === 'rectangle') {
          return `<rect x="${el.x}" y="${el.y}" width="${w}" height="${h}" fill="${fill}" stroke="${el.strokeColor}" stroke-width="${el.strokeWidth}"${opacity}${transform} />`;
        }
        if (el.shape === 'ellipse') {
          return `<ellipse cx="${el.x + w / 2}" cy="${el.y + h / 2}" rx="${Math.abs(w / 2)}" ry="${Math.abs(
            h / 2
          )}" fill="${fill}" stroke="${el.strokeColor}" stroke-width="${el.strokeWidth}"${opacity}${transform} />`;
        }
        return `<line x1="${el.x}" y1="${el.y}" x2="${el.x + w}" y2="${el.y + h}" stroke="${el.strokeColor}" stroke-width="${el.strokeWidth}"${opacity}${transform} />`;
      }
      case 'image': {
        const w = el.width * el.scaleX;
        const h = el.height * el.scaleY;
        return `<image x="${el.x}" y="${el.y}" width="${w}" height="${h}" href="${el.src}"${opacity}${transform} />`;
      }
      default:
        return '';
    }
  }
}

function escapeXml(s: string): string {
  return s.replace(/[<>&'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]!));
}
