import type { CanvasManager } from './CanvasManager';
import type { Camera } from './Camera';
import type { Scene } from './Scene';
import type { Selection } from './Selection';
import { ImageLoader } from './ImageLoader';
import type { BoardElement } from '@/models/Element';
import { getElementBounds } from '@/models/Element';
import { paintElement } from './ElementPainter';

export interface RenderSettings {
  showGrid: boolean;
}

const BG_COLOR = '#0a0d10';
const NICE_STEPS = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000];
const TARGET_MINOR_PX = 48;

export type OverlayDrawFn = (ctx: CanvasRenderingContext2D) => void;

/**
 * Retained-scene renderer. Draws the grid + only the elements that
 * intersect the current viewport (via Scene's spatial index), then any
 * active tool overlay (marquee, in-progress stroke, selection handles).
 * The canvas transform is set to match the camera once per frame, so all
 * element/grid drawing happens directly in world coordinates.
 */
export class Renderer {
  private hiddenElementId: string | null = null;

  constructor(
    private canvasManager: CanvasManager,
    private camera: Camera,
    private scene: Scene,
    private selection: Selection,
    private imageLoader: ImageLoader,
    private settings: RenderSettings,
    private requestRedraw: () => void
  ) {
    this.imageLoader.onReady(() => this.requestRedraw());
  }

  setHiddenElement(id: string | null): void {
    this.hiddenElementId = id;
  }

  render(overlay?: OverlayDrawFn): void {
    const ctx = this.canvasManager.ctx;
    const { width, height } = this.canvasManager;

    this.canvasManager.applyDprTransform();
    ctx.fillStyle = BG_COLOR;
    ctx.fillRect(0, 0, width, height);

    const zoom = this.camera.zoom;
    ctx.save();
    ctx.translate(width / 2, height / 2);
    ctx.scale(zoom, zoom);
    ctx.translate(-this.camera.x, -this.camera.y);

    if (this.settings.showGrid) this.drawGrid(ctx);

    const visibleRect = this.camera.getVisibleWorldRect();
    const padding = (visibleRect.maxX - visibleRect.minX) * 0.05;
    const elements = this.scene.queryVisible({
      minX: visibleRect.minX - padding,
      minY: visibleRect.minY - padding,
      maxX: visibleRect.maxX + padding,
      maxY: visibleRect.maxY + padding,
    });

    for (const el of elements) {
      if (el.id === this.hiddenElementId) continue;
      this.drawElement(ctx, el);
    }

    this.drawSelectionOverlays(ctx);

    if (overlay) overlay(ctx);

    ctx.restore();
  }

  private drawGrid(ctx: CanvasRenderingContext2D): void {
    const zoom = this.camera.zoom;
    let step = NICE_STEPS[NICE_STEPS.length - 1]!;
    for (const s of NICE_STEPS) {
      if (s * zoom >= TARGET_MINOR_PX) {
        step = s;
        break;
      }
    }
    const majorStep = step * 5;
    const rect = this.camera.getVisibleWorldRect();

    const minorScreenPx = step * zoom;
    const fadeIn = Math.min(1, Math.max(0, (minorScreenPx - 8) / (TARGET_MINOR_PX - 8)));

    ctx.lineWidth = 1 / zoom;

    const startX = Math.floor(rect.minX / step) * step;
    const startY = Math.floor(rect.minY / step) * step;

    ctx.strokeStyle = `rgba(57, 255, 157, ${0.05 * fadeIn})`;
    ctx.beginPath();
    for (let x = startX; x <= rect.maxX; x += step) {
      if (Math.abs(x % majorStep) < step / 2) continue;
      ctx.moveTo(x, rect.minY);
      ctx.lineTo(x, rect.maxY);
    }
    for (let y = startY; y <= rect.maxY; y += step) {
      if (Math.abs(y % majorStep) < step / 2) continue;
      ctx.moveTo(rect.minX, y);
      ctx.lineTo(rect.maxX, y);
    }
    ctx.stroke();

    const majorStartX = Math.floor(rect.minX / majorStep) * majorStep;
    const majorStartY = Math.floor(rect.minY / majorStep) * majorStep;
    ctx.strokeStyle = `rgba(57, 255, 157, ${0.13 * Math.max(fadeIn, 0.5)})`;
    ctx.beginPath();
    for (let x = majorStartX; x <= rect.maxX; x += majorStep) {
      ctx.moveTo(x, rect.minY);
      ctx.lineTo(x, rect.maxY);
    }
    for (let y = majorStartY; y <= rect.maxY; y += majorStep) {
      ctx.moveTo(rect.minX, y);
      ctx.lineTo(rect.maxX, y);
    }
    ctx.stroke();

    // Origin axes, slightly stronger cyan tint.
    if (rect.minX <= 0 && rect.maxX >= 0) {
      ctx.strokeStyle = 'rgba(90, 216, 255, 0.18)';
      ctx.beginPath();
      ctx.moveTo(0, rect.minY);
      ctx.lineTo(0, rect.maxY);
      ctx.stroke();
    }
    if (rect.minY <= 0 && rect.maxY >= 0) {
      ctx.strokeStyle = 'rgba(90, 216, 255, 0.18)';
      ctx.beginPath();
      ctx.moveTo(rect.minX, 0);
      ctx.lineTo(rect.maxX, 0);
      ctx.stroke();
    }
  }

  private drawElement(ctx: CanvasRenderingContext2D, el: BoardElement): void {
    if (el.type === 'image' && !this.imageLoader.isLoaded(el.src)) {
      ctx.save();
      ctx.strokeStyle = 'rgba(90, 216, 255, 0.35)';
      ctx.lineWidth = 1 / this.camera.zoom;
      ctx.setLineDash([6 / this.camera.zoom, 4 / this.camera.zoom]);
      ctx.strokeRect(el.x, el.y, el.width * el.scaleX, el.height * el.scaleY);
      ctx.restore();
    }
    paintElement(ctx, el, this.imageLoader);
  }

  private drawSelectionOverlays(ctx: CanvasRenderingContext2D): void {
    if (this.selection.size === 0) return;
    const zoom = this.camera.zoom;
    const handleSize = 8 / zoom;

    for (const id of this.selection.getIds()) {
      const el = this.scene.getElement(id);
      if (!el) continue;
      const w = el.width * el.scaleX;
      const h = el.height * el.scaleY;
      const cx = el.x + w / 2;
      const cy = el.y + h / 2;

      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(el.rotation);
      ctx.translate(-w / 2, -h / 2);

      ctx.strokeStyle = 'rgba(57, 255, 157, 0.85)';
      ctx.lineWidth = 1.5 / zoom;
      ctx.setLineDash([4 / zoom, 3 / zoom]);
      ctx.strokeRect(0, 0, w, h);
      ctx.setLineDash([]);

      if (this.selection.size === 1) {
        ctx.fillStyle = '#0d1210';
        ctx.strokeStyle = 'rgba(57, 255, 157, 0.95)';
        ctx.lineWidth = 1.2 / zoom;
        const corners = [
          [0, 0],
          [w, 0],
          [0, h],
          [w, h],
          [w / 2, 0],
          [w / 2, h],
          [0, h / 2],
          [w, h / 2],
        ];
        for (const [hx, hy] of corners) {
          ctx.beginPath();
          ctx.rect(hx! - handleSize / 2, hy! - handleSize / 2, handleSize, handleSize);
          ctx.fill();
          ctx.stroke();
        }

        // Rotate handle above top-center.
        const rotHandleDist = 24 / zoom;
        ctx.strokeStyle = 'rgba(90, 216, 255, 0.6)';
        ctx.beginPath();
        ctx.moveTo(w / 2, 0);
        ctx.lineTo(w / 2, -rotHandleDist);
        ctx.stroke();
        ctx.beginPath();
        ctx.fillStyle = '#0d1210';
        ctx.strokeStyle = 'rgba(90, 216, 255, 0.9)';
        ctx.arc(w / 2, -rotHandleDist, handleSize / 2, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }

      ctx.restore();
    }

    if (this.selection.size > 1) {
      const bounds = this.selection.getBounds(this.scene);
      if (bounds) {
        ctx.strokeStyle = 'rgba(90, 216, 255, 0.5)';
        ctx.lineWidth = 1 / zoom;
        ctx.setLineDash([6 / zoom, 4 / zoom]);
        ctx.strokeRect(bounds.minX, bounds.minY, bounds.maxX - bounds.minX, bounds.maxY - bounds.minY);
        ctx.setLineDash([]);
      }
    }
  }
}

export function elementScreenBounds(camera: Camera, el: BoardElement) {
  const b = getElementBounds(el);
  const topLeft = camera.worldToScreen(b.minX, b.minY);
  const bottomRight = camera.worldToScreen(b.maxX, b.maxY);
  return { x: topLeft.x, y: topLeft.y, width: bottomRight.x - topLeft.x, height: bottomRight.y - topLeft.y };
}
