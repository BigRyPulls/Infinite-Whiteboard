import type { Tool, ToolContext, PointerInfo } from './Tool';

/** Default navigation tool: drag anywhere to pan the camera. */
export class PanTool implements Tool {
  readonly id = 'pan' as const;
  private dragging = false;
  private lastX = 0;
  private lastY = 0;

  constructor(private ctx: ToolContext) {}

  onActivate(): void {
    this.ctx.setCursor('grab');
  }

  onPointerDown(p: PointerInfo): void {
    this.dragging = true;
    this.lastX = p.screenX;
    this.lastY = p.screenY;
    this.ctx.setCursor('grabbing');
  }

  onPointerMove(p: PointerInfo): void {
    if (!this.dragging) return;
    const dx = p.screenX - this.lastX;
    const dy = p.screenY - this.lastY;
    this.lastX = p.screenX;
    this.lastY = p.screenY;
    this.ctx.camera.panByScreenDelta(dx, dy);
    this.ctx.requestRender();
  }

  onPointerUp(): void {
    this.dragging = false;
    this.ctx.setCursor('grab');
  }
}
