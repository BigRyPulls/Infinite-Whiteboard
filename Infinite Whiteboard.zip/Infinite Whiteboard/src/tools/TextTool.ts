import type { Tool, ToolContext, PointerInfo } from './Tool';
import type { TextAlign, TextElement } from '@/models/Element';
import { createElementBase } from '@/models/Element';
import { AddElementCommand, UpdateElementCommand } from '@/app/History';

export interface TextSettings {
  fontSize: number;
  fontFamily: string;
  bold: boolean;
  italic: boolean;
  align: TextAlign;
  color: string;
}

const DEFAULT_WIDTH = 260;

/** Click to place a new text box; double click (routed in from
 * SelectionTool) to edit an existing one. Editing happens via a
 * transparent textarea overlaid on top of the canvas, positioned to
 * track the camera so it stays pinned to the element in world space. */
export class TextTool implements Tool {
  readonly id = 'text' as const;
  settings: TextSettings = {
    fontSize: 20,
    fontFamily: "'JetBrains Mono', 'IBM Plex Mono', monospace",
    bold: false,
    italic: false,
    align: 'left',
    color: '#d8ece2',
  };

  private editing: { el: TextElement; textarea: HTMLTextAreaElement; isNew: boolean; originalText: string; unsub: () => void } | null =
    null;

  constructor(private ctx: ToolContext) {}

  onActivate(): void {
    this.ctx.setCursor('text');
  }

  onDeactivate(): void {
    this.commitEdit();
  }

  onPointerDown(p: PointerInfo): void {
    if (p.button !== 0) return;
    if (this.editing) {
      this.commitEdit();
      return;
    }
    const base = createElementBase({
      type: 'text',
      x: p.worldX,
      y: p.worldY,
      width: DEFAULT_WIDTH,
      height: this.settings.fontSize * 1.35,
      layer: this.ctx.scene.allocateLayer(),
    });
    const el: TextElement = {
      ...base,
      type: 'text',
      text: '',
      fontSize: this.settings.fontSize,
      fontFamily: this.settings.fontFamily,
      bold: this.settings.bold,
      italic: this.settings.italic,
      align: this.settings.align,
      color: this.settings.color,
      lineHeight: 1.35,
    };
    this.ctx.scene.addElement(el);
    this.beginEdit(el, true);
  }

  onPointerMove(): void {}
  onPointerUp(): void {}

  /** Entry point used by SelectionTool for double-click-to-edit. */
  editElement(el: TextElement): void {
    this.beginEdit(el, false);
  }

  private beginEdit(el: TextElement, isNew: boolean): void {
    this.ctx.setHiddenElement(el.id);
    const textarea = document.createElement('textarea');
    textarea.className = 'text-edit-overlay';
    textarea.value = el.text;
    textarea.spellcheck = false;
    this.ctx.uiRoot.appendChild(textarea);

    const sync = () => this.syncOverlayTransform(el, textarea);
    sync();
    const unsub = this.ctx.camera.onChange(sync);

    textarea.addEventListener('input', () => {
      el.text = textarea.value;
      this.autosize(el, textarea);
      this.ctx.requestRender();
    });
    textarea.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Escape') {
        e.preventDefault();
        this.cancelEdit();
      } else if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        this.commitEdit();
      }
    });
    textarea.addEventListener('blur', () => this.commitEdit());

    this.editing = { el, textarea, isNew, originalText: el.text, unsub };
    requestAnimationFrame(() => {
      textarea.focus();
      textarea.select();
    });
  }

  private syncOverlayTransform(el: TextElement, textarea: HTMLTextAreaElement): void {
    const zoom = this.ctx.camera.zoom;
    const topLeft = this.ctx.camera.worldToScreen(el.x, el.y);
    textarea.style.left = `${topLeft.x}px`;
    textarea.style.top = `${topLeft.y}px`;
    textarea.style.width = `${el.width * el.scaleX * zoom}px`;
    textarea.style.height = `${el.height * el.scaleY * zoom}px`;
    textarea.style.fontSize = `${el.fontSize * zoom}px`;
    textarea.style.fontFamily = el.fontFamily;
    textarea.style.fontWeight = el.bold ? 'bold' : 'normal';
    textarea.style.fontStyle = el.italic ? 'italic' : 'normal';
    textarea.style.color = el.color;
    textarea.style.textAlign = el.align;
    textarea.style.lineHeight = `${el.lineHeight}`;
    textarea.style.transformOrigin = 'top left';
    textarea.style.transform = el.rotation ? `rotate(${el.rotation}rad)` : '';
  }

  private autosize(el: TextElement, textarea: HTMLTextAreaElement): void {
    const zoom = this.ctx.camera.zoom;
    textarea.style.height = 'auto';
    const naturalHeight = textarea.scrollHeight;
    textarea.style.height = `${naturalHeight}px`;
    el.height = Math.max(this.settings.fontSize * 1.35, naturalHeight / zoom);
    this.ctx.scene.refreshBounds(el.id);
  }

  private cancelEdit(): void {
    if (!this.editing) return;
    const { el, textarea, isNew, originalText, unsub } = this.editing;
    unsub();
    textarea.remove();
    this.ctx.setHiddenElement(null);
    this.editing = null;
    if (isNew) {
      this.ctx.scene.removeElement(el.id);
    } else {
      this.ctx.scene.updateElement(el.id, (e) => {
        if (e.type === 'text') e.text = originalText;
      });
    }
    this.ctx.requestRender();
  }

  commitEdit(): void {
    if (!this.editing) return;
    const { el, textarea, isNew, originalText, unsub } = this.editing;
    unsub();
    const finalText = textarea.value;
    textarea.remove();
    this.ctx.setHiddenElement(null);
    this.editing = null;

    if (finalText.trim() === '') {
      this.ctx.scene.removeElement(el.id);
      this.ctx.requestRender();
      return;
    }

    el.text = finalText;
    this.ctx.scene.refreshBounds(el.id);

    if (isNew) {
      this.ctx.history.record(new AddElementCommand(this.ctx.scene, el));
    } else if (finalText !== originalText) {
      this.ctx.history.record(new UpdateElementCommand(this.ctx.scene, el.id, { text: originalText }, { text: finalText }));
    }
    this.ctx.requestRender();
  }

  isEditing(): boolean {
    return this.editing !== null;
  }
}
