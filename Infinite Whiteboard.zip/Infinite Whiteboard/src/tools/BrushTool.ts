import type { Tool, ToolContext, PointerInfo } from './Tool';
import type { StrokeElement, StrokePoint } from '@/models/Element';
import { createElementBase, getElementBounds } from '@/models/Element';
import { AddElementCommand, BatchCommand, RemoveElementsCommand, UpdateElementCommand, type Command } from '@/app/History';

export interface BrushSettings {
  color: string;
  size: number;
  opacity: number;
  mode: 'draw' | 'erase';
  eraserSize: number;
}

const MIN_SCREEN_SAMPLE_DIST = 2.5;

/** Freehand drawing + point-level eraser. Strokes are stored as vector
 * point lists (not raster), so they stay crisp at any zoom and erasing
 * genuinely deletes points rather than painting over pixels. */
export class BrushTool implements Tool {
  readonly id = 'brush' as const;
  settings: BrushSettings = { color: '#39ff9d', size: 4, opacity: 1, mode: 'draw', eraserSize: 24 };

  private drawing = false;
  private current: StrokeElement | null = null;
  private lastPoint: StrokePoint | null = null;

  // Eraser drag bookkeeping.
  private eraseSnapshots = new Map<string, StrokeElement>();
  private eraseCurrentPoints = new Map<string, StrokePoint[]>();
  private eraseRemoved = new Set<string>();

  constructor(private ctx: ToolContext) {}

  onActivate(): void {
    this.ctx.setCursor(this.settings.mode === 'erase' ? 'cell' : 'crosshair');
  }

  onPointerDown(p: PointerInfo): void {
    if (p.button !== 0) return;
    if (this.settings.mode === 'erase') {
      this.eraseSnapshots.clear();
      this.eraseCurrentPoints.clear();
      this.eraseRemoved.clear();
      this.eraseAt(p.worldX, p.worldY);
      this.drawing = true;
      return;
    }

    const base = createElementBase({
      type: 'stroke',
      x: p.worldX,
      y: p.worldY,
      width: 0,
      height: 0,
      layer: this.ctx.scene.allocateLayer(),
    });
    this.current = {
      ...base,
      type: 'stroke',
      points: [{ x: p.worldX, y: p.worldY }],
      color: this.settings.color,
      size: this.settings.size,
      smoothing: 0.5,
      opacity: this.settings.opacity,
    };
    this.lastPoint = { x: p.worldX, y: p.worldY };
    this.ctx.scene.addElement(this.current);
    this.ctx.requestRender();
    this.drawing = true;
  }

  onPointerMove(p: PointerInfo): void {
    if (!this.drawing) return;

    if (this.settings.mode === 'erase') {
      this.eraseAt(p.worldX, p.worldY);
      return;
    }

    if (!this.current || !this.lastPoint) return;
    const threshold = MIN_SCREEN_SAMPLE_DIST / this.ctx.camera.zoom;
    const dx = p.worldX - this.lastPoint.x;
    const dy = p.worldY - this.lastPoint.y;
    if (dx * dx + dy * dy < threshold * threshold) return;

    this.lastPoint = { x: p.worldX, y: p.worldY };
    this.current.points.push(this.lastPoint);
    this.ctx.scene.refreshBounds(this.current.id);
    this.ctx.scene.markDirty();
    this.ctx.requestRender();
  }

  onPointerUp(): void {
    if (!this.drawing) return;
    this.drawing = false;

    if (this.settings.mode === 'erase') {
      this.finalizeErase();
      return;
    }

    if (this.current) {
      const el = this.current;
      const bounds = getElementBounds(el);
      el.x = bounds.minX;
      el.y = bounds.minY;
      el.width = Math.max(1, bounds.maxX - bounds.minX);
      el.height = Math.max(1, bounds.maxY - bounds.minY);
      this.ctx.scene.refreshBounds(el.id);
      this.ctx.history.record(new AddElementCommand(this.ctx.scene, el));
    }
    this.current = null;
    this.lastPoint = null;
    this.ctx.requestRender();
  }

  private eraseAt(wx: number, wy: number): void {
    const r = this.settings.eraserSize / 2;
    const ids = this.ctx.scene.queryVisible({ minX: wx - r, minY: wy - r, maxX: wx + r, maxY: wy + r });
    for (const el of ids) {
      if (el.type !== 'stroke') continue;
      if (!this.eraseSnapshots.has(el.id)) {
        this.eraseSnapshots.set(el.id, structuredClone(el));
        this.eraseCurrentPoints.set(el.id, el.points.map((pt) => ({ ...pt })));
      }
      const points = this.eraseCurrentPoints.get(el.id)!;
      const filtered: StrokePoint[] = [];
      let prevRemoved = false;
      let changed = false;
      for (const pt of points) {
        const dx = pt.x - wx;
        const dy = pt.y - wy;
        if (dx * dx + dy * dy <= r * r) {
          prevRemoved = true;
          changed = true;
          continue;
        }
        const next: StrokePoint = { x: pt.x, y: pt.y };
        if (prevRemoved && filtered.length > 0) next.newSubpath = true;
        filtered.push(next);
        prevRemoved = false;
      }
      if (!changed) continue;
      this.eraseCurrentPoints.set(el.id, filtered);

      if (filtered.length < 2) {
        this.eraseRemoved.add(el.id);
        this.ctx.scene.removeElement(el.id);
      } else {
        this.ctx.scene.updateElement(el.id, (e) => {
          if (e.type !== 'stroke') return;
          e.points = filtered;
          const b = getElementBounds(e);
          e.x = b.minX;
          e.y = b.minY;
          e.width = Math.max(1, b.maxX - b.minX);
          e.height = Math.max(1, b.maxY - b.minY);
        });
      }
    }
    this.ctx.requestRender();
  }

  private finalizeErase(): void {
    if (this.eraseSnapshots.size === 0) return;
    const commands: Command[] = [];
    for (const [id, before] of this.eraseSnapshots) {
      const removed = this.eraseRemoved.has(id);
      const afterPoints = this.eraseCurrentPoints.get(id) ?? [];
      if (removed) {
        commands.push(new RemoveElementsCommand(this.ctx.scene, [before]));
        // Element is already removed live; RemoveElementsCommand.execute() re-removes (no-op) and undo re-adds — matches desired semantics.
      } else {
        commands.push(new UpdateElementCommand(this.ctx.scene, id, { points: before.points }, { points: afterPoints }));
      }
    }
    this.ctx.history.record(new BatchCommand(commands, 'Erase'));
    this.eraseSnapshots.clear();
    this.eraseCurrentPoints.clear();
    this.eraseRemoved.clear();
  }

  renderOverlay(ctx: CanvasRenderingContext2D): void {
    if (this.settings.mode !== 'erase') return;
    // Eraser cursor ring is drawn by the app-level overlay via last known pointer; simplified here as no-op.
    void ctx;
  }

  setMode(mode: 'draw' | 'erase'): void {
    this.settings.mode = mode;
    this.ctx.setCursor(mode === 'erase' ? 'cell' : 'crosshair');
  }
}
