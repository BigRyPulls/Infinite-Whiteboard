import type { Tool, ToolContext, PointerInfo } from './Tool';
import type { ImageElement } from '@/models/Element';
import { createElementBase } from '@/models/Element';
import { AddElementCommand } from '@/app/History';
import { fileToDataUrl } from '@/app/ImageLoader';

const ACCEPTED_TYPES = ['image/png', 'image/jpeg', 'image/webp', 'image/svg+xml'];
const MAX_PLACED_DIMENSION = 480;

/** Handles importing images from a file picker, drag-and-drop, or the
 * clipboard, decoding them, and placing them on the board as regular
 * (movable/resizable/rotatable) ImageElements. */
export class ImageTool implements Tool {
  readonly id = 'image' as const;
  private pendingPos: { x: number; y: number } | null = null;
  private fileInput: HTMLInputElement;

  constructor(private ctx: ToolContext) {
    this.fileInput = document.createElement('input');
    this.fileInput.type = 'file';
    this.fileInput.accept = ACCEPTED_TYPES.join(',');
    this.fileInput.multiple = true;
    this.fileInput.style.display = 'none';
    this.fileInput.addEventListener('change', () => {
      if (this.fileInput.files && this.fileInput.files.length > 0) {
        void this.importFiles(this.fileInput.files, this.pendingPos ?? { x: this.ctx.camera.x, y: this.ctx.camera.y });
      }
      this.fileInput.value = '';
    });
    document.body.appendChild(this.fileInput);
  }

  onActivate(): void {
    this.ctx.setCursor('copy');
  }

  onPointerDown(p: PointerInfo): void {
    if (p.button !== 0) return;
    this.pendingPos = { x: p.worldX, y: p.worldY };
    this.fileInput.click();
  }
  onPointerMove(): void {}
  onPointerUp(): void {}

  /** Opens the native picker without requiring the tool to be active
   * (used by the toolbar "Import Image" button). */
  openPicker(): void {
    this.pendingPos = { x: this.ctx.camera.x, y: this.ctx.camera.y };
    this.fileInput.click();
  }

  async importFiles(files: FileList | File[], worldPos: { x: number; y: number }): Promise<void> {
    const list = Array.from(files);
    let offset = 0;
    for (const file of list) {
      if (!ACCEPTED_TYPES.includes(file.type) && !/\.(png|jpe?g|webp|svg)$/i.test(file.name)) {
        this.ctx.notify(`Unsupported image type: ${file.name}`, 'warn');
        continue;
      }
      try {
        await this.importSingleFile(file, { x: worldPos.x + offset, y: worldPos.y + offset });
        offset += 24;
      } catch (err) {
        console.error(err);
        this.ctx.notify(`Failed to import ${file.name}`, 'error');
      }
    }
  }

  private async importSingleFile(file: File, worldPos: { x: number; y: number }): Promise<void> {
    const dataUrl = await fileToDataUrl(file);
    const entry = await this.ctx.imageLoader.load(dataUrl);
    const scale = Math.min(1, MAX_PLACED_DIMENSION / Math.max(entry.width, entry.height));
    const width = Math.max(8, entry.width * scale);
    const height = Math.max(8, entry.height * scale);

    const base = createElementBase({
      type: 'image',
      x: worldPos.x - width / 2,
      y: worldPos.y - height / 2,
      width,
      height,
      layer: this.ctx.scene.allocateLayer(),
    });
    const el: ImageElement = {
      ...base,
      type: 'image',
      src: dataUrl,
      naturalWidth: entry.width,
      naturalHeight: entry.height,
      aspectLocked: true,
    };
    this.ctx.history.record(new AddElementCommand(this.ctx.scene, el));
    this.ctx.selection.set([el.id]);
    this.ctx.requestRender();
  }

  dispose(): void {
    this.fileInput.remove();
  }
}
