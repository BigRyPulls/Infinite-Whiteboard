import type { Tool, ToolContext, PointerInfo } from './Tool';
import type { ShapeElement, ShapeKind } from '@/models/Element';
import { createElementBase } from '@/models/Element';
import { AddElementCommand } from '@/app/History';

export interface ShapeSettings {
  shape: ShapeKind;
  strokeColor: string;
  fillColor: string | null;
  strokeWidth: number;
}

/** Drag-to-create rectangle / ellipse / line / arrow shapes. */
export class ShapeTool implements Tool {
  readonly id = 'shape' as const;
  settings: ShapeSettings = { shape: 'rectangle', strokeColor: '#5ad8ff', fillColor: null, strokeWidth: 2 };

  private startX = 0;
  private startY = 0;
  private current: ShapeElement | null = null;
  private dragging = false;

  constructor(private ctx: ToolContext) {}

  onActivate(): void {
    this.ctx.setCursor('crosshair');
  }

  onPointerDown(p: PointerInfo): void {
    if (p.button !== 0) return;
    this.dragging = true;
    this.startX = this.ctx.snapValue(p.worldX);
    this.startY = this.ctx.snapValue(p.worldY);

    const base = createElementBase({
      type: 'shape',
      x: this.startX,
      y: this.startY,
      width: 0,
      height: 0,
      layer: this.ctx.scene.allocateLayer(),
    });
    this.current = {
      ...base,
      type: 'shape',
      shape: this.settings.shape,
      strokeColor: this.settings.strokeColor,
      fillColor: this.settings.fillColor,
      strokeWidth: this.settings.strokeWidth,
    };
    this.ctx.scene.addElement(this.current);
    this.ctx.requestRender();
  }

  onPointerMove(p: PointerInfo): void {
    if (!this.dragging || !this.current) return;
    const wx = this.ctx.snapValue(p.worldX);
    const wy = this.ctx.snapValue(p.worldY);
    const el = this.current;
    el.x = Math.min(this.startX, wx);
    el.y = Math.min(this.startY, wy);
    el.width = Math.abs(wx - this.startX);
    el.height = Math.abs(wy - this.startY);
    if (el.shape === 'line' || el.shape === 'arrow') {
      // Preserve direction for line/arrow instead of always normalizing to top-left.
      el.x = this.startX;
      el.y = this.startY;
      el.width = wx - this.startX;
      el.height = wy - this.startY;
    }
    this.ctx.scene.refreshBounds(el.id);
    this.ctx.scene.markDirty();
    this.ctx.requestRender();
  }

  onPointerUp(): void {
    if (!this.dragging) return;
    this.dragging = false;
    if (this.current) {
      const el = this.current;
      const tooSmall = Math.abs(el.width) < 2 && Math.abs(el.height) < 2;
      if (tooSmall) {
        this.ctx.scene.removeElement(el.id);
      } else {
        this.ctx.history.record(new AddElementCommand(this.ctx.scene, el));
      }
    }
    this.current = null;
    this.ctx.requestRender();
  }
}
