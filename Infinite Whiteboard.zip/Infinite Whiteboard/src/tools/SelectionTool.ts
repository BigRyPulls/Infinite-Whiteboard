import type { Tool, ToolContext, PointerInfo } from './Tool';
import type { BoardElement } from '@/models/Element';
import { AddElementsCommand, BatchCommand, RemoveElementsCommand, UpdateElementCommand, type Command } from '@/app/History';
import type { AABB } from '@/app/SpatialIndex';

type HandleId = 'nw' | 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w' | 'rotate';
type Mode = 'idle' | 'marquee' | 'move' | 'resize' | 'rotate';

const HANDLE_HIT_PX = 10;
const ROTATE_HANDLE_DIST = 24;

interface DragSnapshot {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  points?: { x: number; y: number }[];
}

function toLocal(px: number, py: number, cx: number, cy: number, rotation: number): { x: number; y: number } {
  const dx = px - cx;
  const dy = py - cy;
  const cos = Math.cos(-rotation);
  const sin = Math.sin(-rotation);
  return { x: dx * cos - dy * sin + cx, y: dx * sin + dy * cos + cy };
}

/** Rectangle marquee select, click select, drag move, 8-handle resize,
 * rotate handle, alt-drag duplicate, and double-click-to-edit-text. */
export class SelectionTool implements Tool {
  readonly id = 'select' as const;
  private mode: Mode = 'idle';
  private startWorld = { x: 0, y: 0 };
  private marqueeRect: AABB | null = null;
  private activeHandle: HandleId | null = null;
  private dragSnapshots: DragSnapshot[] = [];
  private rotationCenter = { x: 0, y: 0 };
  private rotationOffset = 0;
  private didDuplicate = false;
  private marqueeAdditive = false;
  private preMarqueeSelection: string[] = [];

  constructor(private ctx: ToolContext) {}

  onActivate(): void {
    this.ctx.setCursor('default');
  }

  onDeactivate(): void {
    this.mode = 'idle';
    this.marqueeRect = null;
  }

  onPointerDown(p: PointerInfo): void {
    if (p.button !== 0) return;
    this.startWorld = { x: p.worldX, y: p.worldY };

    if (this.ctx.selection.size >= 1) {
      const handle = this.hitTestHandles(p.worldX, p.worldY);
      if (handle) {
        this.beginHandleDrag(handle, p);
        return;
      }
    }

    const hit = this.hitTest(p.worldX, p.worldY);
    if (hit) {
      if (p.shiftKey) {
        this.ctx.selection.toggle(hit.id);
        this.mode = 'idle';
        return;
      }
      if (!this.ctx.selection.isSelected(hit.id)) {
        this.ctx.selection.set([hit.id]);
      }
      this.beginMoveDrag(p);
      return;
    }

    this.marqueeAdditive = p.shiftKey;
    this.preMarqueeSelection = this.ctx.selection.getIds();
    if (!p.shiftKey) this.ctx.selection.clear();
    this.mode = 'marquee';
    this.marqueeRect = { minX: p.worldX, minY: p.worldY, maxX: p.worldX, maxY: p.worldY };
  }

  onPointerMove(p: PointerInfo): void {
    switch (this.mode) {
      case 'marquee':
        this.updateMarquee(p);
        break;
      case 'move':
        this.updateMove(p);
        break;
      case 'resize':
        this.updateResize(p);
        break;
      case 'rotate':
        this.updateRotate(p);
        break;
      default:
        this.updateHoverCursor(p);
    }
  }

  onPointerUp(): void {
    if (this.mode === 'move' || this.mode === 'resize') {
      this.finalizeTransform(this.mode === 'move' ? 'Move' : 'Resize');
    } else if (this.mode === 'rotate') {
      this.finalizeTransform('Rotate');
    }
    this.mode = 'idle';
    this.marqueeRect = null;
    this.activeHandle = null;
    this.ctx.requestRender();
  }

  onDoubleClick(p: PointerInfo): void {
    const hit = this.hitTest(p.worldX, p.worldY);
    if (hit && hit.type === 'text') {
      this.ctx.editTextElement(hit);
    }
  }

  onKeyDown(e: KeyboardEvent): boolean {
    if (e.key === 'Delete' || e.key === 'Backspace') {
      this.deleteSelection();
      return true;
    }
    return false;
  }

  renderOverlay(ctx: CanvasRenderingContext2D): void {
    if (this.mode === 'marquee' && this.marqueeRect) {
      const r = this.marqueeRect;
      ctx.fillStyle = 'rgba(57, 255, 157, 0.08)';
      ctx.strokeStyle = 'rgba(57, 255, 157, 0.6)';
      ctx.lineWidth = 1 / this.ctx.camera.zoom;
      ctx.fillRect(r.minX, r.minY, r.maxX - r.minX, r.maxY - r.minY);
      ctx.strokeRect(r.minX, r.minY, r.maxX - r.minX, r.maxY - r.minY);
    }
  }

  deleteSelection(): void {
    const ids = this.ctx.selection.getIds();
    if (ids.length === 0) return;
    const elements = ids.map((id) => this.ctx.scene.getElement(id)).filter((e): e is BoardElement => !!e);
    this.ctx.history.push(new RemoveElementsCommand(this.ctx.scene, elements));
    this.ctx.selection.clear();
    this.ctx.requestRender();
  }

  duplicateSelection(): void {
    const ids = this.ctx.selection.getIds();
    if (ids.length === 0) return;
    const clones = ids
      .map((id) => this.ctx.scene.getElement(id))
      .filter((e): e is BoardElement => !!e)
      .map((e) => {
        const clone = structuredClone(e);
        clone.id = `${e.type}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
        clone.x += 16;
        clone.y += 16;
        clone.layer = this.ctx.scene.allocateLayer();
        return clone;
      });
    this.ctx.history.push(new AddElementsCommand(this.ctx.scene, clones));
    this.ctx.selection.set(clones.map((c) => c.id));
    this.ctx.requestRender();
  }

  // ---- hit testing --------------------------------------------------------

  private hitTest(wx: number, wy: number): BoardElement | null {
    const pad = 4;
    const candidates = this.ctx.scene.queryVisible({ minX: wx - pad, minY: wy - pad, maxX: wx + pad, maxY: wy + pad });
    for (let i = candidates.length - 1; i >= 0; i--) {
      const el = candidates[i]!;
      if (el.locked) continue;
      const w = el.width * el.scaleX;
      const h = el.height * el.scaleY;
      const cx = el.x + w / 2;
      const cy = el.y + h / 2;
      const local = toLocal(wx, wy, cx, cy, el.rotation);
      const withinBox = local.x >= el.x - pad && local.x <= el.x + w + pad && local.y >= el.y - pad && local.y <= el.y + h + pad;
      if (withinBox) return el;
    }
    return null;
  }

  private hitTestHandles(wx: number, wy: number): HandleId | null {
    if (this.ctx.selection.size !== 1) return null;
    const id = this.ctx.selection.getIds()[0]!;
    const el = this.ctx.scene.getElement(id);
    if (!el) return null;
    const zoom = this.ctx.camera.zoom;
    const tol = HANDLE_HIT_PX / zoom;
    const w = el.width * el.scaleX;
    const h = el.height * el.scaleY;
    const cx = el.x + w / 2;
    const cy = el.y + h / 2;
    const local = toLocal(wx, wy, cx, cy, el.rotation);

    const handles: [HandleId, number, number][] = [
      ['nw', el.x, el.y],
      ['n', el.x + w / 2, el.y],
      ['ne', el.x + w, el.y],
      ['e', el.x + w, el.y + h / 2],
      ['se', el.x + w, el.y + h],
      ['s', el.x + w / 2, el.y + h],
      ['sw', el.x, el.y + h],
      ['w', el.x, el.y + h / 2],
      ['rotate', el.x + w / 2, el.y - ROTATE_HANDLE_DIST / zoom],
    ];
    for (const [id_, hx, hy] of handles) {
      if (Math.abs(local.x - hx) <= tol && Math.abs(local.y - hy) <= tol) return id_;
    }
    return null;
  }

  private updateHoverCursor(p: PointerInfo): void {
    const handle = this.hitTestHandles(p.worldX, p.worldY);
    const cursors: Record<HandleId, string> = {
      nw: 'nwse-resize',
      n: 'ns-resize',
      ne: 'nesw-resize',
      e: 'ew-resize',
      se: 'nwse-resize',
      s: 'ns-resize',
      sw: 'nesw-resize',
      w: 'ew-resize',
      rotate: 'grab',
    };
    if (handle) {
      this.ctx.setCursor(cursors[handle]);
      return;
    }
    const hit = this.hitTest(p.worldX, p.worldY);
    this.ctx.setCursor(hit ? 'move' : 'default');
  }

  // ---- marquee -------------------------------------------------------------

  private updateMarquee(p: PointerInfo): void {
    this.marqueeRect = {
      minX: Math.min(this.startWorld.x, p.worldX),
      minY: Math.min(this.startWorld.y, p.worldY),
      maxX: Math.max(this.startWorld.x, p.worldX),
      maxY: Math.max(this.startWorld.y, p.worldY),
    };
    const hits = this.ctx.scene.queryVisible(this.marqueeRect).map((e) => e.id);
    const combined = this.marqueeAdditive ? Array.from(new Set([...this.preMarqueeSelection, ...hits])) : hits;
    this.ctx.selection.set(combined);
    this.ctx.requestRender();
  }

  // ---- move ------------------------------------------------------------

  private beginMoveDrag(p: PointerInfo): void {
    this.mode = 'move';
    this.didDuplicate = false;
    if (p.altKey) {
      this.duplicateSelectionInPlace();
    }
    this.dragSnapshots = this.ctx.selection.getIds().map((id) => this.snapshotOf(id)).filter((s): s is DragSnapshot => !!s);
  }

  private duplicateSelectionInPlace(): void {
    const ids = this.ctx.selection.getIds();
    const clones = ids
      .map((id) => this.ctx.scene.getElement(id))
      .filter((e): e is BoardElement => !!e)
      .map((e) => {
        const clone = structuredClone(e);
        clone.id = `${e.type}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
        clone.layer = this.ctx.scene.allocateLayer();
        return clone;
      });
    for (const c of clones) this.ctx.scene.addElement(c, false);
    this.ctx.scene.markDirty();
    this.ctx.selection.set(clones.map((c) => c.id));
    this.didDuplicate = true;
  }

  private snapshotOf(id: string): DragSnapshot | null {
    const el = this.ctx.scene.getElement(id);
    if (!el) return null;
    return {
      id,
      x: el.x,
      y: el.y,
      width: el.width,
      height: el.height,
      rotation: el.rotation,
      points: el.type === 'stroke' ? el.points.map((pt) => ({ x: pt.x, y: pt.y })) : undefined,
    };
  }

  private updateMove(p: PointerInfo): void {
    const dx = this.ctx.snapValue(p.worldX) - this.ctx.snapValue(this.startWorld.x);
    const dy = this.ctx.snapValue(p.worldY) - this.ctx.snapValue(this.startWorld.y);
    for (const snap of this.dragSnapshots) {
      this.ctx.scene.updateElement(
        snap.id,
        (el) => {
          el.x = snap.x + dx;
          el.y = snap.y + dy;
          if (el.type === 'stroke' && snap.points) {
            el.points = snap.points.map((pt) => ({ ...pt, x: pt.x + dx, y: pt.y + dy }));
          }
        },
        false
      );
    }
    this.ctx.scene.markDirty();
    this.ctx.requestRender();
  }

  // ---- resize ------------------------------------------------------------

  private beginHandleDrag(handle: HandleId, p: PointerInfo): void {
    this.activeHandle = handle;
    this.mode = handle === 'rotate' ? 'rotate' : 'resize';
    const id = this.ctx.selection.getIds()[0]!;
    this.dragSnapshots = [this.snapshotOf(id)!];

    if (handle === 'rotate') {
      const el = this.ctx.scene.getElement(id)!;
      const w = el.width * el.scaleX;
      const h = el.height * el.scaleY;
      this.rotationCenter = { x: el.x + w / 2, y: el.y + h / 2 };
      const angleToPointer = Math.atan2(p.worldY - this.rotationCenter.y, p.worldX - this.rotationCenter.x);
      this.rotationOffset = el.rotation - angleToPointer;
    }
  }

  private updateResize(p: PointerInfo): void {
    const snap = this.dragSnapshots[0];
    const handle = this.activeHandle;
    if (!snap || !handle) return;

    const cx = snap.x + snap.width / 2;
    const cy = snap.y + snap.height / 2;
    const local = toLocal(p.worldX, p.worldY, cx, cy, snap.rotation);

    const origLeft = snap.x;
    const origTop = snap.y;
    const origRight = snap.x + snap.width;
    const origBottom = snap.y + snap.height;
    const aspect = snap.width !== 0 ? snap.width / snap.height : 1;
    const lockAspect = this.ctx.scene.getElement(snap.id)?.type === 'image' || false;

    let x = origLeft;
    let y = origTop;
    let width = snap.width;
    let height = snap.height;

    switch (handle) {
      case 'nw':
        x = local.x;
        y = local.y;
        width = origRight - local.x;
        height = origBottom - local.y;
        break;
      case 'ne':
        y = local.y;
        width = local.x - origLeft;
        height = origBottom - local.y;
        x = origLeft;
        break;
      case 'se':
        width = local.x - origLeft;
        height = local.y - origTop;
        break;
      case 'sw':
        x = local.x;
        width = origRight - local.x;
        height = local.y - origTop;
        y = origTop;
        break;
      case 'n':
        y = local.y;
        height = origBottom - local.y;
        break;
      case 's':
        height = local.y - origTop;
        break;
      case 'e':
        width = local.x - origLeft;
        break;
      case 'w':
        x = local.x;
        width = origRight - local.x;
        break;
      case 'rotate':
        return;
    }

    if (lockAspect && (handle === 'nw' || handle === 'ne' || handle === 'se' || handle === 'sw')) {
      height = width / aspect;
      if (handle === 'nw' || handle === 'ne') y = origBottom - height;
      if (handle === 'nw' || handle === 'sw') x = origRight - width;
    }

    const MIN = 4;
    if (width < MIN) {
      width = MIN;
      if (handle === 'nw' || handle === 'sw' || handle === 'w') x = origRight - MIN;
    }
    if (height < MIN) {
      height = MIN;
      if (handle === 'nw' || handle === 'ne' || handle === 'n') y = origBottom - MIN;
    }

    this.ctx.scene.updateElement(
      snap.id,
      (el) => {
        el.x = x;
        el.y = y;
        el.width = width;
        el.height = height;
      },
      false
    );
    this.ctx.scene.markDirty();
    this.ctx.requestRender();
  }

  private updateRotate(p: PointerInfo): void {
    const snap = this.dragSnapshots[0];
    if (!snap) return;
    const angleToPointer = Math.atan2(p.worldY - this.rotationCenter.y, p.worldX - this.rotationCenter.x);
    let rotation = angleToPointer + this.rotationOffset;
    if (p.shiftKey) {
      const step = Math.PI / 12; // 15 degrees
      rotation = Math.round(rotation / step) * step;
    }
    this.ctx.scene.updateElement(snap.id, (el) => (el.rotation = rotation), false);
    this.ctx.scene.markDirty();
    this.ctx.requestRender();
  }

  // ---- finalize --------------------------------------------------------

  private finalizeTransform(label: string): void {
    if (this.dragSnapshots.length === 0) return;
    const commands: Command[] = [];

    if (this.didDuplicate) {
      const clones = this.dragSnapshots
        .map((s) => this.ctx.scene.getElement(s.id))
        .filter((e): e is BoardElement => !!e);
      commands.push(new AddElementsCommand(this.ctx.scene, clones));
    } else {
      for (const snap of this.dragSnapshots) {
        const el = this.ctx.scene.getElement(snap.id);
        if (!el) continue;
        const before: Record<string, unknown> = { x: snap.x, y: snap.y, width: snap.width, height: snap.height, rotation: snap.rotation };
        const after: Record<string, unknown> = { x: el.x, y: el.y, width: el.width, height: el.height, rotation: el.rotation };
        if (snap.points) {
          before.points = snap.points;
          after.points = el.type === 'stroke' ? el.points : snap.points;
        }
        const unchanged = JSON.stringify(before) === JSON.stringify(after);
        if (!unchanged) commands.push(new UpdateElementCommand(this.ctx.scene, snap.id, before, after));
      }
    }

    if (commands.length > 0) {
      this.ctx.history.record(commands.length === 1 ? commands[0]! : new BatchCommand(commands, label));
    }
    this.dragSnapshots = [];
    this.didDuplicate = false;
  }
}
