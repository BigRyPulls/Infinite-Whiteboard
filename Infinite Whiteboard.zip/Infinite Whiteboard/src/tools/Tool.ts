import type { Scene } from '@/app/Scene';
import type { Selection } from '@/app/Selection';
import type { History } from '@/app/History';
import type { Camera } from '@/app/Camera';
import type { ImageLoader } from '@/app/ImageLoader';
import type { TextElement } from '@/models/Element';

export type ToolId = 'select' | 'pan' | 'brush' | 'text' | 'shape' | 'image';

export interface PointerInfo {
  screenX: number;
  screenY: number;
  worldX: number;
  worldY: number;
  button: number;
  shiftKey: boolean;
  altKey: boolean;
  ctrlKey: boolean;
  pointerType: string;
  pointerId: number;
}

/** Narrow surface each tool needs from the rest of the app. Keeps tools
 * decoupled from App/UI while still able to mutate scene state, push
 * history, and request redraws. */
export interface ToolContext {
  scene: Scene;
  selection: Selection;
  history: History;
  camera: Camera;
  imageLoader: ImageLoader;
  requestRender: () => void;
  setCursor: (cursor: string) => void;
  setHiddenElement: (id: string | null) => void;
  notify: (message: string, kind?: 'info' | 'error' | 'warn') => void;
  getSnapEnabled: () => boolean;
  snapValue: (v: number) => number;
  uiRoot: HTMLElement;
  editTextElement: (el: TextElement) => void;
  openContextMenu: (screenX: number, screenY: number) => void;
}

export interface Tool {
  readonly id: ToolId;
  onActivate?(): void;
  onDeactivate?(): void;
  onPointerDown(p: PointerInfo): void;
  onPointerMove(p: PointerInfo): void;
  onPointerUp(p: PointerInfo): void;
  onDoubleClick?(p: PointerInfo): void;
  onKeyDown?(e: KeyboardEvent): boolean;
  renderOverlay?(ctx: CanvasRenderingContext2D): void;
}
