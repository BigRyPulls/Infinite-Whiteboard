import type { App } from '@/app/App';
import type { ToolId } from '@/tools/Tool';

interface ToolButtonDef {
  id: ToolId;
  label: string;
  title: string;
}

const TOOL_BUTTONS: ToolButtonDef[] = [
  { id: 'select', label: 'SEL', title: 'Selection (V)' },
  { id: 'pan', label: 'PAN', title: 'Pan — hold Space (H)' },
  { id: 'brush', label: 'BRUSH', title: 'Brush (B)' },
  { id: 'text', label: 'TEXT', title: 'Text (T)' },
  { id: 'shape', label: 'SHAPE', title: 'Shape (S)' },
];

/** Top floating toolbar: history, file ops, tool switcher, zoom, grid/snap. */
export class Toolbar {
  private el: HTMLDivElement;
  private undoBtn!: HTMLButtonElement;
  private redoBtn!: HTMLButtonElement;
  private gridBtn!: HTMLButtonElement;
  private snapBtn!: HTMLButtonElement;
  private zoomValue!: HTMLSpanElement;
  private toolButtons = new Map<ToolId, HTMLButtonElement>();

  constructor(private app: App, root: HTMLElement) {
    this.el = document.createElement('div');
    this.el.className = 'toolbar panel';
    root.appendChild(this.el);
    this.build();

    app.history.onChange(() => this.refresh());
    app.camera.onChange(() => this.updateZoom());
  }

  private button(label: string, title: string, onClick: (e: MouseEvent) => void, iconOnly = false): HTMLButtonElement {
    const b = document.createElement('button');
    b.className = `btn${iconOnly ? ' icon-only' : ''}`;
    b.textContent = label;
    b.title = title;
    b.addEventListener('click', onClick);
    return b;
  }

  private divider(): HTMLDivElement {
    const d = document.createElement('div');
    d.className = 'btn-divider';
    return d;
  }

  private build(): void {
    this.undoBtn = this.button('↶', 'Undo (Ctrl+Z)', () => this.app.undo(), true);
    this.redoBtn = this.button('↷', 'Redo (Ctrl+Shift+Z)', () => this.app.redo(), true);
    this.el.append(this.undoBtn, this.redoBtn, this.divider());

    this.el.append(
      this.button('SAVE', 'Save board (Ctrl+S)', () => void this.app.storage.saveToFile(this.app.suggestedFileName())),
      this.button('LOAD', 'Load board (Ctrl+O)', () => void this.app.storage.loadFromFile()),
      this.button('IMG', 'Import image', () => this.app.imageTool.openPicker()),
      this.button('EXPORT', 'Export board…', (e) => this.showExportMenu(e)),
      this.divider()
    );

    for (const def of TOOL_BUTTONS) {
      const btn = this.button(def.label, def.title, () => this.app.setActiveTool(def.id));
      this.toolButtons.set(def.id, btn);
      this.el.appendChild(btn);
    }
    this.el.appendChild(this.divider());

    const zoomOut = this.button('−', 'Zoom out', () => this.zoomStep(1 / 1.25), true);
    this.zoomValue = document.createElement('span');
    this.zoomValue.className = 'zoom-value';
    const zoomIn = this.button('+', 'Zoom in', () => this.zoomStep(1.25), true);
    const zoomReset = this.button('100%', 'Reset zoom', () => this.resetZoom());
    this.el.append(zoomOut, this.zoomValue, zoomIn, zoomReset, this.divider());

    this.gridBtn = this.button('GRID', 'Toggle grid', () => this.toggleGrid());
    this.snapBtn = this.button('SNAP', 'Toggle snap-to-grid', () => this.toggleSnap());
    this.el.append(this.gridBtn, this.snapBtn);

    this.updateZoom();
    this.refresh();
  }

  private showExportMenu(e: MouseEvent): void {
    this.app.ui.contextMenu.open(e.clientX, e.clientY, [
      { label: 'PNG — Board', onSelect: () => this.app.exportBoard('board', 'png') },
      { label: 'PNG — Viewport', onSelect: () => this.app.exportBoard('viewport', 'png') },
      { label: 'SVG — Board', onSelect: () => this.app.exportBoard('board', 'svg') },
      { label: 'SVG — Viewport', onSelect: () => this.app.exportBoard('viewport', 'svg') },
      'separator',
      { label: 'JSON Project', onSelect: () => this.app.exportBoard('board', 'json') },
    ]);
  }

  private zoomStep(factor: number): void {
    const cx = this.app.canvasManager.width / 2;
    const cy = this.app.canvasManager.height / 2;
    this.app.camera.zoomAt(cx, cy, factor);
  }

  private resetZoom(): void {
    const cx = this.app.canvasManager.width / 2;
    const cy = this.app.canvasManager.height / 2;
    this.app.camera.setZoomAt(cx, cy, 1);
  }

  private toggleGrid(): void {
    this.app.renderSettings.showGrid = !this.app.renderSettings.showGrid;
    this.gridBtn.classList.toggle('active', this.app.renderSettings.showGrid);
    this.app.requestRender();
  }

  private toggleSnap(): void {
    this.app.snapEnabled = !this.app.snapEnabled;
    this.snapBtn.classList.toggle('active', this.app.snapEnabled);
  }

  private updateZoom(): void {
    this.zoomValue.textContent = `${Math.round(this.app.camera.zoom * 100)}%`;
  }

  refresh(): void {
    this.undoBtn.disabled = !this.app.history.canUndo;
    this.redoBtn.disabled = !this.app.history.canRedo;
    for (const [id, btn] of this.toolButtons) {
      btn.classList.toggle('active', id === this.app.activeToolId);
    }
    this.gridBtn.classList.toggle('active', this.app.renderSettings.showGrid);
    this.snapBtn.classList.toggle('active', this.app.snapEnabled);
  }
}
