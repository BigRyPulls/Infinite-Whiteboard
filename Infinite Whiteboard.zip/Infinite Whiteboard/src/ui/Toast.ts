export type ToastKind = 'info' | 'error' | 'warn';

const AUTO_DISMISS_MS = 3600;
const LEAVE_ANIM_MS = 220;

/** Minimal bottom-right toast stack — dark translucent panels with a
 * neon accent border, auto-dismissing. */
export class Toast {
  private container: HTMLDivElement;

  constructor(root: HTMLElement) {
    this.container = document.createElement('div');
    this.container.className = 'toast-stack';
    root.appendChild(this.container);
  }

  show(message: string, kind: ToastKind = 'info'): void {
    const el = document.createElement('div');
    el.className = `toast ${kind}`;
    el.textContent = message;
    this.container.appendChild(el);

    const timer = window.setTimeout(() => this.dismiss(el), AUTO_DISMISS_MS);
    el.addEventListener('click', () => {
      window.clearTimeout(timer);
      this.dismiss(el);
    });
  }

  private dismiss(el: HTMLElement): void {
    el.classList.add('leaving');
    window.setTimeout(() => el.remove(), LEAVE_ANIM_MS);
  }
}
