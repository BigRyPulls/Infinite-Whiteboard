import type { App } from '@/app/App';
import type { BoardElement } from '@/models/Element';
import { UpdateElementCommand, BatchCommand, type Command } from '@/app/History';

const COLOR_SWATCHES = ['#39ff9d', '#5ad8ff', '#a78bfa', '#ffb454', '#ff5d7a', '#d8ece2'];

function colorFieldOf(el: BoardElement): string | null {
  if (el.type === 'stroke' || el.type === 'text') return el.color;
  if (el.type === 'shape') return el.strokeColor;
  return null;
}

/** Floating panel shown whenever there is an active selection. Edits are
 * applied live to the scene and committed to history as a single batch
 * once the user finishes interacting with a control. */
export class PropertyPanel {
  private el: HTMLDivElement;
  private beforeSnapshot: Map<string, Record<string, unknown>> | null = null;

  constructor(private app: App, root: HTMLElement) {
    this.el = document.createElement('div');
    this.el.className = 'property-panel panel hidden';
    root.appendChild(this.el);

    this.app.selection.onChange(() => this.refresh());
    this.app.scene.onChange(() => {
      if (this.app.selection.size > 0) this.refresh();
    });
  }

  private ids(): string[] {
    return this.app.selection.getIds();
  }

  private elements(): BoardElement[] {
    return this.ids()
      .map((id) => this.app.scene.getElement(id))
      .filter((e): e is BoardElement => !!e);
  }

  private beginEdit(): void {
    this.beforeSnapshot = new Map(
      this.elements().map((el) => [
        el.id,
        { x: el.x, y: el.y, rotation: el.rotation, scaleX: el.scaleX, scaleY: el.scaleY, opacity: el.opacity } as Record<
          string,
          unknown
        >,
      ])
    );
  }

  private commitEdit(fields: (keyof BoardElement)[]): void {
    if (!this.beforeSnapshot) return;
    const commands: Command[] = [];
    for (const el of this.elements()) {
      const before = this.beforeSnapshot.get(el.id);
      if (!before) continue;
      const beforePatch: Record<string, unknown> = {};
      const afterPatch: Record<string, unknown> = {};
      let changed = false;
      for (const f of fields) {
        if (before[f] !== (el as unknown as Record<string, unknown>)[f]) {
          beforePatch[f] = before[f];
          afterPatch[f] = (el as unknown as Record<string, unknown>)[f];
          changed = true;
        }
      }
      if (changed) commands.push(new UpdateElementCommand(this.app.scene, el.id, beforePatch, afterPatch));
    }
    if (commands.length > 0) {
      this.app.history.record(commands.length === 1 ? commands[0]! : new BatchCommand(commands, 'Edit properties'));
    }
    this.beforeSnapshot = null;
  }

  private numberInput(value: number, onInput: (v: number) => void, step = 1): HTMLInputElement {
    const input = document.createElement('input');
    input.type = 'number';
    input.step = String(step);
    input.value = String(Math.round(value * 100) / 100);
    input.addEventListener('focus', () => this.beginEdit());
    input.addEventListener('input', () => {
      const v = Number(input.value);
      if (!Number.isNaN(v)) onInput(v);
      this.app.scene.markDirty();
      this.app.requestRender();
    });
    input.addEventListener('change', () => this.commitEdit(['x', 'y', 'rotation', 'scaleX', 'scaleY', 'opacity']));
    return input;
  }

  private recordLayerChanges(changes: { id: string; before: number; after: number }[], label: string): void {
    if (changes.length === 0) return;
    const commands = changes.map((c) => new UpdateElementCommand(this.app.scene, c.id, { layer: c.before }, { layer: c.after }));
    this.app.history.record(commands.length === 1 ? commands[0]! : new BatchCommand(commands, label));
    this.app.requestRender();
  }

  private row(label: string, ...controls: HTMLElement[]): HTMLDivElement {
    const wrap = document.createElement('div');
    wrap.className = 'field';
    const l = document.createElement('label');
    l.textContent = label;
    wrap.appendChild(l);
    const inner = document.createElement('div');
    inner.className = 'field-row';
    inner.append(...controls);
    wrap.appendChild(inner);
    return wrap;
  }

  refresh(): void {
    const elements = this.elements();
    if (elements.length === 0) {
      this.el.classList.add('hidden');
      return;
    }
    this.el.classList.remove('hidden');
    this.el.innerHTML = '';

    const title = document.createElement('div');
    title.className = 'panel-title';
    title.style.cursor = 'default';
    title.textContent = elements.length === 1 ? elements[0]!.type.toUpperCase() : `${elements.length} objects`;
    this.el.appendChild(title);

    const single = elements.length === 1 ? elements[0]! : null;

    if (single) {
      this.el.appendChild(
        this.row(
          'Position',
          this.numberInput(single.x, (v) => this.app.scene.updateElement(single.id, (e) => (e.x = v), false)),
          this.numberInput(single.y, (v) => this.app.scene.updateElement(single.id, (e) => (e.y = v), false))
        )
      );
      this.el.appendChild(
        this.row(
          'Rotation °',
          this.numberInput(
            (single.rotation * 180) / Math.PI,
            (v) => this.app.scene.updateElement(single.id, (e) => (e.rotation = (v * Math.PI) / 180), false),
            1
          )
        )
      );
      this.el.appendChild(
        this.row(
          'Scale %',
          this.numberInput(
            single.scaleX * 100,
            (v) => this.app.scene.updateElement(single.id, (e) => {
              e.scaleX = v / 100;
              e.scaleY = v / 100;
            }, false),
            5
          )
        )
      );
    }

    const opacitySlider = document.createElement('input');
    opacitySlider.type = 'range';
    opacitySlider.min = '0.05';
    opacitySlider.max = '1';
    opacitySlider.step = '0.05';
    opacitySlider.value = String(single ? single.opacity : elements[0]!.opacity);
    opacitySlider.addEventListener('pointerdown', () => this.beginEdit());
    opacitySlider.addEventListener('input', () => {
      const v = Number(opacitySlider.value);
      for (const el of elements) this.app.scene.updateElement(el.id, (e) => (e.opacity = v), false);
      this.app.scene.markDirty();
      this.app.requestRender();
    });
    opacitySlider.addEventListener('change', () => this.commitEdit(['opacity']));
    this.el.appendChild(this.row('Opacity', opacitySlider));

    const colorables = elements.filter((e) => colorFieldOf(e) !== null);
    if (colorables.length > 0) {
      const swatchRow = document.createElement('div');
      swatchRow.className = 'swatch-row';
      for (const c of COLOR_SWATCHES) {
        const sw = document.createElement('div');
        sw.className = 'swatch';
        sw.style.background = c;
        sw.addEventListener('click', () => {
          const before: Command[] = [];
          for (const el of colorables) {
            const beforeColor = colorFieldOf(el);
            this.app.scene.updateElement(el.id, (e) => {
              if (e.type === 'stroke' || e.type === 'text') e.color = c;
              if (e.type === 'shape') e.strokeColor = c;
            });
            before.push(new UpdateElementCommand(this.app.scene, el.id, { color: beforeColor, strokeColor: beforeColor }, { color: c, strokeColor: c }));
          }
          this.app.history.record(before.length === 1 ? before[0]! : new BatchCommand(before, 'Color'));
          this.app.requestRender();
        });
        swatchRow.appendChild(sw);
      }
      this.el.appendChild(this.row('Color', swatchRow));
    }

    const layerRow = document.createElement('div');
    layerRow.className = 'field-row';
    const front = document.createElement('button');
    front.className = 'btn';
    front.textContent = '⤒ Front';
    front.addEventListener('click', () => {
      const changes = elements.flatMap((el) => this.app.scene.bringToFront(el.id));
      this.recordLayerChanges(changes, 'Bring to Front');
    });
    const back = document.createElement('button');
    back.className = 'btn';
    back.textContent = '⤓ Back';
    back.addEventListener('click', () => {
      const changes = elements.flatMap((el) => this.app.scene.sendToBack(el.id));
      this.recordLayerChanges(changes, 'Send to Back');
    });
    layerRow.append(front, back);
    this.el.appendChild(this.row('Layer', layerRow));

    const lockRow = document.createElement('label');
    lockRow.className = 'checkbox-row';
    const lockBox = document.createElement('input');
    lockBox.type = 'checkbox';
    lockBox.checked = elements.every((e) => e.locked);
    lockBox.addEventListener('change', () => {
      for (const el of elements) this.app.scene.updateElement(el.id, (e) => (e.locked = lockBox.checked));
    });
    lockRow.append(lockBox, document.createTextNode('Locked'));

    const visRow = document.createElement('label');
    visRow.className = 'checkbox-row';
    const visBox = document.createElement('input');
    visBox.type = 'checkbox';
    visBox.checked = elements.every((e) => e.visible);
    visBox.addEventListener('change', () => {
      for (const el of elements) this.app.scene.updateElement(el.id, (e) => (e.visible = visBox.checked));
    });
    visRow.append(visBox, document.createTextNode('Visible'));

    const flagsWrap = document.createElement('div');
    flagsWrap.className = 'field-row';
    flagsWrap.append(lockRow, visRow);
    this.el.appendChild(flagsWrap);
  }
}
