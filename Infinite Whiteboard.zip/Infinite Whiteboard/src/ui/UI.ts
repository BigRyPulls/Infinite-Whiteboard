import type { App } from '@/app/App';
import { Toolbar } from './Toolbar';
import { Sidebar } from './Sidebar';
import { StatusBar } from './StatusBar';
import { PropertyPanel } from './PropertyPanel';
import { ContextMenu } from './ContextMenu';
import { Toast } from './Toast';
import type { BoardFile } from '@/models/Board';
import { UpdateElementCommand, BatchCommand } from '@/app/History';

const STATUSBAR_UPDATE_INTERVAL_MS = 200;

/** Composition root for every floating UI widget. Owns no board state
 * itself — just renders/reacts to App's state and forwards user intent
 * back into App/tool methods. */
export class UI {
  readonly toolbar: Toolbar;
  readonly sidebar: Sidebar;
  readonly statusBar: StatusBar;
  readonly propertyPanel: PropertyPanel;
  readonly contextMenu: ContextMenu;
  readonly toast: Toast;

  private lastStatusUpdate = 0;
  private recoveryBanner: HTMLDivElement | null = null;

  constructor(private app: App, private root: HTMLElement) {
    this.toolbar = new Toolbar(app, root);
    this.sidebar = new Sidebar(app, root);
    this.statusBar = new StatusBar(app, root);
    this.propertyPanel = new PropertyPanel(app, root);
    this.contextMenu = new ContextMenu(root);
    this.toast = new Toast(root);

    app.onNotify((message, kind) => this.toast.show(message, kind));
    root.addEventListener('pointermove', (e) => this.trackHoverCoords(e));
  }

  private trackHoverCoords(e: PointerEvent): void {
    const rect = this.app.canvasManager.canvas.getBoundingClientRect();
    const world = this.app.camera.screenToWorld(e.clientX - rect.left, e.clientY - rect.top);
    this.app.trackMouseWorld(world.x, world.y);
  }

  refreshToolbar(): void {
    this.toolbar.refresh();
  }

  refreshAll(): void {
    this.toolbar.refresh();
    this.sidebar.refresh();
    this.propertyPanel.refresh();
    this.statusBar.update();
  }

  tickStatusBar(): void {
    const now = performance.now();
    if (now - this.lastStatusUpdate < STATUSBAR_UPDATE_INTERVAL_MS) return;
    this.lastStatusUpdate = now;
    this.statusBar.update();
  }

  openContextMenuAt(clientX: number, clientY: number): void {
    const selectionCount = this.app.selection.size;
    const hasClipboard = this.app.hasClipboardContent();

    this.contextMenu.open(clientX, clientY, [
      {
        label: 'Copy',
        shortcut: 'Ctrl+C',
        disabled: selectionCount === 0,
        onSelect: () => this.app.copySelection(),
      },
      {
        label: 'Paste',
        shortcut: 'Ctrl+V',
        disabled: !hasClipboard,
        onSelect: () => this.app.pasteClipboard(),
      },
      {
        label: 'Duplicate',
        shortcut: 'Ctrl+D',
        disabled: selectionCount === 0,
        onSelect: () => this.app.selectionTool.duplicateSelection(),
      },
      {
        label: 'Delete',
        shortcut: 'Del',
        disabled: selectionCount === 0,
        danger: true,
        onSelect: () => this.app.selectionTool.deleteSelection(),
      },
      'separator',
      {
        label: 'Bring Forward',
        disabled: selectionCount === 0,
        onSelect: () => {
          const changes = this.app.selection.getIds().flatMap((id) => this.app.scene.bringForward(id));
          this.recordLayerChanges(changes, 'Bring Forward');
        },
      },
      {
        label: 'Send Back',
        disabled: selectionCount === 0,
        onSelect: () => {
          const changes = this.app.selection.getIds().flatMap((id) => this.app.scene.sendBackward(id));
          this.recordLayerChanges(changes, 'Send Backward');
        },
      },
      'separator',
      {
        label: 'Create Waypoint Here',
        onSelect: () => {
          const name = window.prompt('Waypoint name', 'New Waypoint');
          if (name) this.app.waypoints.create(name);
        },
      },
    ]);
  }

  closeContextMenu(): void {
    this.contextMenu.close();
  }

  private recordLayerChanges(changes: { id: string; before: number; after: number }[], label: string): void {
    if (changes.length === 0) return;
    const commands = changes.map((c) => new UpdateElementCommand(this.app.scene, c.id, { layer: c.before }, { layer: c.after }));
    this.app.history.record(commands.length === 1 ? commands[0]! : new BatchCommand(commands, label));
    this.app.requestRender();
  }

  promptRecovery(board: BoardFile): void {
    this.recoveryBanner = document.createElement('div');
    this.recoveryBanner.className = 'panel';
    this.recoveryBanner.style.position = 'absolute';
    this.recoveryBanner.style.top = '84px';
    this.recoveryBanner.style.left = '50%';
    this.recoveryBanner.style.transform = 'translateX(-50%)';
    this.recoveryBanner.style.padding = '12px 16px';
    this.recoveryBanner.style.display = 'flex';
    this.recoveryBanner.style.alignItems = 'center';
    this.recoveryBanner.style.gap = '12px';

    const text = document.createElement('span');
    text.style.fontSize = 'var(--fs-sm)';
    text.style.color = 'var(--text-secondary)';
    text.textContent = `Found an autosaved board with ${board.elements.length} object(s). Recover it?`;

    const recoverBtn = document.createElement('button');
    recoverBtn.className = 'btn active';
    recoverBtn.textContent = 'Recover';
    recoverBtn.addEventListener('click', () => {
      this.app.loadBoard(board);
      this.dismissRecovery();
      this.app.notify('Board recovered from autosave.', 'info');
    });

    const discardBtn = document.createElement('button');
    discardBtn.className = 'btn';
    discardBtn.textContent = 'Discard';
    discardBtn.addEventListener('click', () => {
      this.app.storage.clearAutosave();
      this.app.newBoard();
      this.dismissRecovery();
    });

    this.recoveryBanner.append(text, recoverBtn, discardBtn);
    this.root.appendChild(this.recoveryBanner);
  }

  private dismissRecovery(): void {
    this.recoveryBanner?.remove();
    this.recoveryBanner = null;
  }
}
