import type { App } from '@/app/App';

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/** Bottom status strip: zoom, cursor world coordinates, selection count,
 * FPS, object count, rough memory estimate. */
export class StatusBar {
  private el: HTMLDivElement;
  private zoomEl: HTMLSpanElement;
  private coordsEl: HTMLSpanElement;
  private selectionEl: HTMLSpanElement;
  private fpsEl: HTMLSpanElement;
  private countEl: HTMLSpanElement;
  private memEl: HTMLSpanElement;

  constructor(private app: App, root: HTMLElement) {
    this.el = document.createElement('div');
    this.el.className = 'statusbar';

    const zoomGroup = this.group('Zoom');
    this.zoomEl = zoomGroup.value;

    const coordsGroup = this.group('XY');
    this.coordsEl = coordsGroup.value;

    const selGroup = this.group('Selected');
    this.selectionEl = selGroup.value;

    const countGroup = this.group('Objects');
    this.countEl = countGroup.value;

    const memGroup = this.group('Mem');
    this.memEl = memGroup.value;

    const spacer = document.createElement('div');
    spacer.className = 'statusbar-spacer';

    const fpsGroup = this.group('FPS');
    this.fpsEl = fpsGroup.value;

    this.el.append(zoomGroup.el, coordsGroup.el, selGroup.el, countGroup.el, memGroup.el, spacer, fpsGroup.el);
    root.appendChild(this.el);

    this.app.selection.onChange(() => this.update());
  }

  private group(label: string): { el: HTMLDivElement; value: HTMLSpanElement } {
    const el = document.createElement('div');
    el.className = 'statusbar-group';
    const l = document.createElement('span');
    l.textContent = label;
    l.style.color = 'var(--text-tertiary)';
    const v = document.createElement('span');
    v.className = 'value';
    el.append(l, v);
    return { el, value: v };
  }

  update(): void {
    const cam = this.app.camera;
    this.zoomEl.textContent = `${Math.round(cam.zoom * 100)}%`;

    const m = this.app.getMouseWorld();
    this.coordsEl.textContent = `${Math.round(m.x)}, ${Math.round(m.y)}`;

    this.selectionEl.textContent = `${this.app.selection.size}`;
    this.countEl.textContent = `${this.app.scene.size}`;
    this.memEl.textContent = formatBytes(this.app.getMemoryEstimateBytes());

    const fps = this.app.getFps();
    this.fpsEl.textContent = `${fps}`;
    this.fpsEl.className = `value ${fps >= 50 ? 'fps-good' : fps >= 30 ? 'fps-warn' : 'fps-bad'}`;
  }
}
