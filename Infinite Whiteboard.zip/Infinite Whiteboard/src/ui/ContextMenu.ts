export interface ContextMenuAction {
  label: string;
  shortcut?: string;
  danger?: boolean;
  disabled?: boolean;
  onSelect: () => void;
}

/** Floating right-click menu. Rebuilt fresh on every open with whatever
 * action list the caller supplies. */
export class ContextMenu {
  private el: HTMLDivElement;

  constructor(private root: HTMLElement) {
    this.el = document.createElement('div');
    this.el.className = 'context-menu panel hidden';
    root.appendChild(this.el);

    window.addEventListener('pointerdown', (e) => {
      if (!this.el.contains(e.target as Node)) this.close();
    });
    window.addEventListener('resize', () => this.close());
  }

  open(clientX: number, clientY: number, actions: (ContextMenuAction | 'separator')[]): void {
    this.el.innerHTML = '';
    for (const action of actions) {
      if (action === 'separator') {
        const sep = document.createElement('div');
        sep.className = 'context-menu-sep';
        this.el.appendChild(sep);
        continue;
      }
      const item = document.createElement('div');
      item.className = `context-menu-item${action.danger ? ' danger' : ''}`;
      if (action.disabled) item.style.opacity = '0.4';

      const label = document.createElement('span');
      label.textContent = action.label;
      item.appendChild(label);

      if (action.shortcut) {
        const sc = document.createElement('span');
        sc.className = 'shortcut';
        sc.textContent = action.shortcut;
        item.appendChild(sc);
      }

      if (!action.disabled) {
        item.addEventListener('pointerdown', (e) => {
          e.stopPropagation();
          action.onSelect();
          this.close();
        });
      }
      this.el.appendChild(item);
    }

    this.el.classList.remove('hidden');
    const rect = this.root.getBoundingClientRect();
    let x = clientX - rect.left;
    let y = clientY - rect.top;
    const menuRect = this.el.getBoundingClientRect();
    if (x + menuRect.width > rect.width) x -= menuRect.width;
    if (y + menuRect.height > rect.height) y -= menuRect.height;
    this.el.style.left = `${Math.max(4, x)}px`;
    this.el.style.top = `${Math.max(4, y)}px`;
  }

  close(): void {
    this.el.classList.add('hidden');
  }

  isOpen(): boolean {
    return !this.el.classList.contains('hidden');
  }
}
