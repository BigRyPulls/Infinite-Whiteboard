import type { App } from '@/app/App';
import { WAYPOINT_COLORS } from '@/models/Waypoint';
import type { ShapeKind } from '@/models/Element';

const BRUSH_COLORS = ['#39ff9d', '#5ad8ff', '#a78bfa', '#ffb454', '#ff5d7a', '#d8ece2'];
const SHAPE_KINDS: { id: ShapeKind; label: string }[] = [
  { id: 'rectangle', label: '▭ Rect' },
  { id: 'ellipse', label: '◯ Ellipse' },
  { id: 'line', label: '╱ Line' },
  { id: 'arrow', label: '↗ Arrow' },
];

/** Left floating sidebar: contextual tool settings + the waypoint list. */
export class Sidebar {
  private el: HTMLDivElement;
  private brushSection: { section: HTMLDivElement; body: HTMLDivElement };
  private textSection: { section: HTMLDivElement; body: HTMLDivElement };
  private shapeSection: { section: HTMLDivElement; body: HTMLDivElement };
  private waypointList!: HTMLDivElement;

  constructor(private app: App, root: HTMLElement) {
    this.el = document.createElement('div');
    this.el.className = 'sidebar';
    root.appendChild(this.el);

    this.brushSection = this.makeSection('Brush');
    this.textSection = this.makeSection('Text');
    this.shapeSection = this.makeSection('Shape');
    const waypointSection = this.makeSection('Waypoints');

    this.buildBrushSection(this.brushSection.body);
    this.buildTextSection(this.textSection.body);
    this.buildShapeSection(this.shapeSection.body);
    this.buildWaypointSection(waypointSection.body);

    this.app.waypoints.onChange(() => this.refreshWaypoints());
    this.refresh();
  }

  private makeSection(title: string): { section: HTMLDivElement; body: HTMLDivElement } {
    const section = document.createElement('div');
    section.className = 'panel panel-section-wrap';
    section.style.padding = '0';

    const inner = document.createElement('div');
    inner.className = 'panel-section';

    const heading = document.createElement('div');
    heading.className = 'panel-title';
    const label = document.createElement('span');
    label.textContent = title;
    const chev = document.createElement('span');
    chev.className = 'chev';
    chev.textContent = '▾';
    heading.append(label, chev);

    const body = document.createElement('div');
    body.className = 'panel-body';

    heading.addEventListener('click', () => {
      const collapsed = body.classList.toggle('collapsed');
      heading.classList.toggle('collapsed', collapsed);
    });

    inner.append(heading, body);
    section.appendChild(inner);
    this.el.appendChild(section);
    return { section, body };
  }

  private field(label: string, input: HTMLElement): HTMLDivElement {
    const wrap = document.createElement('div');
    wrap.className = 'field';
    const l = document.createElement('label');
    l.textContent = label;
    wrap.append(l, input);
    return wrap;
  }

  private slider(min: number, max: number, step: number, value: number, onInput: (v: number) => void): HTMLInputElement {
    const input = document.createElement('input');
    input.type = 'range';
    input.min = String(min);
    input.max = String(max);
    input.step = String(step);
    input.value = String(value);
    input.addEventListener('input', () => onInput(Number(input.value)));
    return input;
  }

  private swatches(colors: string[], getCurrent: () => string, onPick: (c: string) => void): HTMLDivElement {
    const row = document.createElement('div');
    row.className = 'swatch-row';
    const render = () => {
      row.innerHTML = '';
      for (const c of colors) {
        const sw = document.createElement('div');
        sw.className = `swatch${getCurrent() === c ? ' selected' : ''}`;
        sw.style.background = c;
        sw.addEventListener('click', () => {
          onPick(c);
          render();
        });
        row.appendChild(sw);
      }
    };
    render();
    return row;
  }

  // ---- Brush -------------------------------------------------------------

  private buildBrushSection(body: HTMLDivElement): void {
    const brush = this.app.brushTool;

    const drawBtn = document.createElement('button');
    drawBtn.className = 'btn active';
    drawBtn.textContent = 'Draw';
    const eraseBtn = document.createElement('button');
    eraseBtn.className = 'btn';
    eraseBtn.textContent = 'Erase';
    const modeRow = document.createElement('div');
    modeRow.className = 'field-row';
    modeRow.append(drawBtn, eraseBtn);
    drawBtn.addEventListener('click', () => {
      brush.setMode('draw');
      drawBtn.classList.add('active');
      eraseBtn.classList.remove('active');
    });
    eraseBtn.addEventListener('click', () => {
      brush.setMode('erase');
      eraseBtn.classList.add('active');
      drawBtn.classList.remove('active');
    });
    body.appendChild(modeRow);

    body.appendChild(this.field('Color', this.swatches(BRUSH_COLORS, () => brush.settings.color, (c) => (brush.settings.color = c))));
    body.appendChild(this.field('Size', this.slider(1, 60, 1, brush.settings.size, (v) => (brush.settings.size = v))));
    body.appendChild(
      this.field('Opacity', this.slider(0.05, 1, 0.05, brush.settings.opacity, (v) => (brush.settings.opacity = v)))
    );
    body.appendChild(
      this.field('Eraser size', this.slider(8, 120, 2, brush.settings.eraserSize, (v) => (brush.settings.eraserSize = v)))
    );
  }

  // ---- Text -------------------------------------------------------------

  private buildTextSection(body: HTMLDivElement): void {
    const text = this.app.textTool;

    body.appendChild(
      this.field('Color', this.swatches(BRUSH_COLORS.concat('#d8ece2'), () => text.settings.color, (c) => (text.settings.color = c)))
    );
    body.appendChild(this.field('Font size', this.slider(10, 96, 1, text.settings.fontSize, (v) => (text.settings.fontSize = v))));

    const boldBtn = document.createElement('button');
    boldBtn.className = 'btn';
    boldBtn.textContent = 'B';
    boldBtn.style.fontWeight = 'bold';
    boldBtn.classList.toggle('active', text.settings.bold);
    boldBtn.addEventListener('click', () => {
      text.settings.bold = !text.settings.bold;
      boldBtn.classList.toggle('active', text.settings.bold);
    });

    const italicBtn = document.createElement('button');
    italicBtn.className = 'btn';
    italicBtn.textContent = 'I';
    italicBtn.style.fontStyle = 'italic';
    italicBtn.classList.toggle('active', text.settings.italic);
    italicBtn.addEventListener('click', () => {
      text.settings.italic = !text.settings.italic;
      italicBtn.classList.toggle('active', text.settings.italic);
    });

    const styleRow = document.createElement('div');
    styleRow.className = 'field-row';
    styleRow.append(boldBtn, italicBtn);
    body.appendChild(this.field('Style', styleRow));

    const alignRow = document.createElement('div');
    alignRow.className = 'field-row';
    for (const [align, glyph] of [['left', '⟸'], ['center', '⇔'], ['right', '⟹']] as const) {
      const b = document.createElement('button');
      b.className = `btn${text.settings.align === align ? ' active' : ''}`;
      b.textContent = glyph;
      b.addEventListener('click', () => {
        text.settings.align = align;
        for (const sib of Array.from(alignRow.children)) sib.classList.remove('active');
        b.classList.add('active');
      });
      alignRow.appendChild(b);
    }
    body.appendChild(this.field('Align', alignRow));
  }

  // ---- Shape -------------------------------------------------------------

  private buildShapeSection(body: HTMLDivElement): void {
    const shape = this.app.shapeTool;

    const kindRow = document.createElement('div');
    kindRow.className = 'field-row';
    kindRow.style.flexWrap = 'wrap';
    for (const k of SHAPE_KINDS) {
      const b = document.createElement('button');
      b.className = `btn${shape.settings.shape === k.id ? ' active' : ''}`;
      b.textContent = k.label;
      b.addEventListener('click', () => {
        shape.settings.shape = k.id;
        for (const sib of Array.from(kindRow.children)) sib.classList.remove('active');
        b.classList.add('active');
      });
      kindRow.appendChild(b);
    }
    body.appendChild(this.field('Shape', kindRow));

    body.appendChild(
      this.field(
        'Stroke color',
        this.swatches(BRUSH_COLORS, () => shape.settings.strokeColor, (c) => (shape.settings.strokeColor = c))
      )
    );
    body.appendChild(
      this.field('Stroke width', this.slider(1, 24, 1, shape.settings.strokeWidth, (v) => (shape.settings.strokeWidth = v)))
    );

    const fillToggle = document.createElement('label');
    fillToggle.className = 'checkbox-row';
    const fillCheckbox = document.createElement('input');
    fillCheckbox.type = 'checkbox';
    fillCheckbox.checked = shape.settings.fillColor !== null;
    fillToggle.append(fillCheckbox, document.createTextNode('Filled'));
    const fillSwatches = this.swatches(
      BRUSH_COLORS,
      () => shape.settings.fillColor ?? '',
      (c) => (shape.settings.fillColor = c)
    );
    fillCheckbox.addEventListener('change', () => {
      shape.settings.fillColor = fillCheckbox.checked ? BRUSH_COLORS[0]! : null;
      fillSwatches.style.display = fillCheckbox.checked ? '' : 'none';
    });
    fillSwatches.style.display = fillCheckbox.checked ? '' : 'none';
    body.append(this.field('Fill', fillToggle), fillSwatches);
  }

  // ---- Waypoints -------------------------------------------------------------

  private buildWaypointSection(body: HTMLDivElement): void {
    const addBtn = document.createElement('button');
    addBtn.className = 'btn';
    addBtn.style.width = '100%';
    addBtn.textContent = '+ Add Waypoint Here';
    addBtn.addEventListener('click', () => {
      const name = window.prompt('Waypoint name', `Waypoint ${this.app.waypoints.listSortedAlphabetically().length + 1}`);
      if (name === null) return;
      this.app.waypoints.create(name);
      this.app.notify(`Waypoint "${name}" created`, 'info');
    });
    body.appendChild(addBtn);

    this.waypointList = document.createElement('div');
    body.appendChild(this.waypointList);
    this.refreshWaypoints();
  }

  private refreshWaypoints(): void {
    this.waypointList.innerHTML = '';
    const list = this.app.waypoints.listSortedAlphabetically();
    if (list.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'waypoint-empty';
      empty.textContent = 'No waypoints yet.';
      this.waypointList.appendChild(empty);
      return;
    }
    for (const wp of list) {
      const item = document.createElement('div');
      item.className = 'waypoint-item';

      const dot = document.createElement('span');
      dot.className = 'dot';
      dot.style.background = wp.color ?? WAYPOINT_COLORS[0];
      dot.style.color = wp.color ?? WAYPOINT_COLORS[0];

      const name = document.createElement('span');
      name.className = 'name';
      name.textContent = wp.name;

      const actions = document.createElement('div');
      actions.className = 'wp-actions';

      const renameBtn = document.createElement('button');
      renameBtn.className = 'btn icon-only';
      renameBtn.textContent = '✎';
      renameBtn.title = 'Rename';
      renameBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const next = window.prompt('Rename waypoint', wp.name);
        if (next) this.app.waypoints.rename(wp.id, next);
      });

      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'btn icon-only';
      deleteBtn.textContent = '✕';
      deleteBtn.title = 'Delete';
      deleteBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.app.waypoints.delete(wp.id);
      });

      actions.append(renameBtn, deleteBtn);
      item.append(dot, name, actions);
      item.addEventListener('click', () => this.app.waypoints.jumpTo(wp.id));
      this.waypointList.appendChild(item);
    }
  }

  refresh(): void {
    const tool = this.app.activeToolId;
    this.brushSection.section.classList.toggle('hidden', tool !== 'brush');
    this.textSection.section.classList.toggle('hidden', tool !== 'text');
    this.shapeSection.section.classList.toggle('hidden', tool !== 'shape');
  }
}
