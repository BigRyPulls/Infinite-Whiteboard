import { App } from '@/app/App';

function bootstrap(): void {
  const canvas = document.getElementById('board-canvas');
  const uiRoot = document.getElementById('ui-root');
  if (!(canvas instanceof HTMLCanvasElement) || !(uiRoot instanceof HTMLElement)) {
    throw new Error('Required DOM nodes (#board-canvas, #ui-root) are missing.');
  }

  const app = new App(canvas, uiRoot);
  // Exposed for debugging from the browser console only; not part of the
  // public API surface.
  (window as unknown as { __whiteboard?: App }).__whiteboard = app;
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bootstrap);
} else {
  bootstrap();
}
